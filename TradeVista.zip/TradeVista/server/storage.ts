import { 
  users, User, InsertUser, 
  watchlists, Watchlist, InsertWatchlist, 
  watchlistItems, WatchlistItem, InsertWatchlistItem,
  holdings, Holding, InsertHolding,
  orders, Order, InsertOrder,
  marketIndices, MarketIndex, InsertMarketIndex,
  userSettings, UserSettings, InsertUserSettings,
  tradeSuggestions, TradeSuggestion, InsertTradeSuggestion,
  Stock, ChartData, OptionChain, OptionChainList
} from "@shared/schema";
import { MARKET_INDICES, WATCHLIST_STOCKS, PORTFOLIO_HOLDINGS, RECENT_ORDERS } from "../client/src/lib/constants";

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAvailableMargin(userId: number): Promise<number>;

  // User Settings methods
  getUserSettings(userId: number): Promise<UserSettings | undefined>;
  createUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  updateUserSettings(userId: number, settings: Partial<InsertUserSettings>): Promise<UserSettings>;
  toggleAI(userId: number, enabled: boolean): Promise<UserSettings>;
  toggleDarkMode(userId: number, enabled: boolean): Promise<UserSettings>;

  // AI Trade Suggestions methods
  getTradeSuggestions(userId: number, limit?: number): Promise<TradeSuggestion[]>;
  createTradeSuggestion(suggestion: InsertTradeSuggestion): Promise<TradeSuggestion>;
  markTradeSuggestionAsRead(suggestionId: number): Promise<void>;

  // Market data methods
  getMarketIndices(): Promise<MarketIndex[]>;
  getStockPrice(symbol: string): Promise<Stock | undefined>;
  getStockChart(symbol: string, period: string): Promise<Stock | undefined>;
  searchStocks(query: string): Promise<Stock[]>;
  
  // Options data methods
  getOptionChain(symbol: string, expiryDate: string): Promise<OptionChainList | undefined>;
  getExpiryDates(symbol: string): Promise<string[]>;

  // Watchlist methods
  getWatchlists(userId: number): Promise<Watchlist[]>;
  createWatchlist(watchlist: InsertWatchlist): Promise<Watchlist>;
  getWatchlistItems(watchlistId: number): Promise<Stock[]>;
  addToWatchlist(item: InsertWatchlistItem): Promise<WatchlistItem>;
  removeFromWatchlist(watchlistId: number, itemId: number): Promise<void>;

  // Portfolio methods
  getHoldings(userId: number): Promise<Holding[]>;
  getPortfolioSummary(userId: number): Promise<{
    currentValue: number;
    investedValue: number;
    totalPnl: number;
    totalPnlPercentage: number;
    availableMargin: number;
  }>;

  // Order methods
  getOrders(userId: number): Promise<Order[]>;
  getRecentOrders(userId: number, limit: number): Promise<Order[]>;
  placeOrder(order: InsertOrder): Promise<Order>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private watchlists: Map<number, Watchlist>;
  private watchlistItems: Map<number, WatchlistItem>;
  private holdings: Map<number, Holding>;
  private orders: Map<number, Order>;
  private marketIndices: Map<number, MarketIndex>;
  private userSettings: Map<number, UserSettings>;
  private tradeSuggestions: Map<number, TradeSuggestion>;
  
  private userId: number = 1;
  private watchlistId: number = 1;
  private watchlistItemId: number = 1;
  private holdingId: number = 1;
  private orderId: number = 1;
  private marketIndexId: number = 1;
  private userSettingsId: number = 1;
  private tradeSuggestionId: number = 1;

  constructor() {
    this.users = new Map();
    this.watchlists = new Map();
    this.watchlistItems = new Map();
    this.holdings = new Map();
    this.orders = new Map();
    this.marketIndices = new Map();
    this.userSettings = new Map();
    this.tradeSuggestions = new Map();

    // Initialize with some data
    this.initializeData();
  }

  // Initialize sample data
  private initializeData() {
    // Create a default user
    this.users.set(1, {
      id: 1,
      username: "john_doe",
      password: "password"
    });
    
    // Create default user settings
    this.userSettings.set(1, {
      id: 1,
      userId: 1,
      aiEnabled: true,
      darkMode: false,
      language: "hinglish",
      riskTolerance: "medium",
      aiModel: "gpt-4o",
      lastUpdated: new Date()
    });
    
    // Create AI trade suggestions
    const suggestions = [
      {
        id: this.tradeSuggestionId++,
        userId: 1,
        symbol: "RELIANCE",
        action: "buy",
        confidence: 0.85,
        riskLevel: "medium",
        reason: "Strong technical breakout with increasing volume and positive market sentiment",
        targetPrice: 2780.50,
        stopLoss: 2650.00,
        expiryDate: null,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
        isRead: false
      },
      {
        id: this.tradeSuggestionId++,
        userId: 1,
        symbol: "HDFCBANK",
        action: "sell",
        confidence: 0.72,
        riskLevel: "high",
        reason: "Negative divergence on RSI with overhead resistance and banking sector weakness",
        targetPrice: 1620.00,
        stopLoss: 1720.00,
        expiryDate: null,
        createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
        isRead: true
      },
      {
        id: this.tradeSuggestionId++,
        userId: 1,
        symbol: "NIFTY",
        action: "hold",
        confidence: 0.68,
        riskLevel: "low",
        reason: "Market in consolidation phase, waiting for clear directional movement before taking position",
        targetPrice: null,
        stopLoss: null,
        expiryDate: null,
        createdAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
        isRead: false
      }
    ];
    
    suggestions.forEach(suggestion => {
      this.tradeSuggestions.set(suggestion.id, suggestion);
    });

    // Create default watchlist
    this.watchlists.set(1, {
      id: 1,
      userId: 1,
      name: "My Watchlist"
    });

    this.watchlists.set(2, {
      id: 2,
      userId: 1,
      name: "Tech Stocks"
    });

    // Add default watchlist items
    WATCHLIST_STOCKS.forEach((stock, index) => {
      this.watchlistItems.set(index + 1, {
        id: index + 1,
        watchlistId: 1,
        symbol: stock.symbol,
        companyName: stock.companyName
      });
      this.watchlistItemId = index + 2;
    });

    // Add default holdings
    PORTFOLIO_HOLDINGS.forEach((holding, index) => {
      this.holdings.set(index + 1, {
        id: index + 1,
        userId: 1,
        symbol: holding.symbol,
        companyName: holding.companyName,
        quantity: holding.quantity,
        averagePrice: holding.averagePrice,
        investmentValue: holding.quantity * holding.averagePrice
      });
      this.holdingId = index + 2;
    });

    // Add default orders
    RECENT_ORDERS.forEach((order, index) => {
      this.orders.set(index + 1, {
        id: index + 1,
        userId: 1,
        symbol: order.symbol,
        orderType: order.orderType,
        transactionType: order.orderType === "Buy" ? "buy" : "sell",
        quantity: order.quantity,
        price: order.price,
        status: order.status,
        createdAt: new Date(order.timestamp)
      });
      this.orderId = index + 2;
    });

    // Add default market indices
    MARKET_INDICES.forEach((index, i) => {
      this.marketIndices.set(i + 1, {
        id: i + 1,
        name: index.name,
        value: index.value,
        change: index.change,
        percentageChange: index.percentageChange,
        updatedAt: new Date()
      });
      this.marketIndexId = i + 2;
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAvailableMargin(userId: number): Promise<number> {
    return 125000.00; // Hardcoded for now
  }
  
  // User settings methods
  async getUserSettings(userId: number): Promise<UserSettings | undefined> {
    return this.userSettings.get(userId);
  }
  
  async createUserSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const id = this.userSettingsId++;
    const newSettings: UserSettings = { 
      id,
      userId: settings.userId,
      aiEnabled: settings.aiEnabled ?? false,
      darkMode: settings.darkMode ?? false,
      language: settings.language ?? "hinglish",
      riskTolerance: settings.riskTolerance ?? "medium",
      aiModel: settings.aiModel ?? "gpt-4o",
      lastUpdated: new Date() 
    };
    this.userSettings.set(settings.userId, newSettings);
    return newSettings;
  }
  
  async updateUserSettings(userId: number, settings: Partial<InsertUserSettings>): Promise<UserSettings> {
    const existingSettings = await this.getUserSettings(userId);
    
    if (!existingSettings) {
      throw new Error(`User settings not found for user ID: ${userId}`);
    }
    
    const updatedSettings: UserSettings = {
      ...existingSettings,
      ...settings,
      lastUpdated: new Date()
    };
    
    this.userSettings.set(userId, updatedSettings);
    return updatedSettings;
  }
  
  async toggleAI(userId: number, enabled: boolean): Promise<UserSettings> {
    return this.updateUserSettings(userId, { aiEnabled: enabled });
  }
  
  async toggleDarkMode(userId: number, enabled: boolean): Promise<UserSettings> {
    return this.updateUserSettings(userId, { darkMode: enabled });
  }
  
  // Trade suggestion methods
  async getTradeSuggestions(userId: number, limit?: number): Promise<TradeSuggestion[]> {
    const suggestions = Array.from(this.tradeSuggestions.values())
      .filter(suggestion => suggestion.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      
    if (limit) {
      return suggestions.slice(0, limit);
    }
    
    return suggestions;
  }
  
  async createTradeSuggestion(suggestion: InsertTradeSuggestion): Promise<TradeSuggestion> {
    const id = this.tradeSuggestionId++;
    const newSuggestion: TradeSuggestion = {
      id,
      userId: suggestion.userId,
      symbol: suggestion.symbol,
      action: suggestion.action,
      confidence: suggestion.confidence,
      riskLevel: suggestion.riskLevel,
      reason: suggestion.reason,
      targetPrice: suggestion.targetPrice ?? null,
      stopLoss: suggestion.stopLoss ?? null,
      expiryDate: suggestion.expiryDate ?? null,
      createdAt: new Date(),
      isRead: suggestion.isRead ?? false
    };
    
    this.tradeSuggestions.set(id, newSuggestion);
    return newSuggestion;
  }
  
  async markTradeSuggestionAsRead(suggestionId: number): Promise<void> {
    const suggestion = this.tradeSuggestions.get(suggestionId);
    
    if (!suggestion) {
      throw new Error(`Trade suggestion not found with ID: ${suggestionId}`);
    }
    
    suggestion.isRead = true;
    this.tradeSuggestions.set(suggestionId, suggestion);
  }

  // Market data methods
  async getMarketIndices(): Promise<MarketIndex[]> {
    return Array.from(this.marketIndices.values());
  }

  async getStockPrice(symbol: string): Promise<Stock | undefined> {
    const stock = WATCHLIST_STOCKS.find(s => s.symbol === symbol);
    if (!stock) return undefined;
    
    return {
      ...stock,
      data: this.generateChartData("1d")
    };
  }

  async getStockChart(symbol: string, period: string): Promise<Stock | undefined> {
    const stock = WATCHLIST_STOCKS.find(s => s.symbol === symbol);
    if (!stock) return undefined;
    
    return {
      ...stock,
      data: this.generateChartData(period)
    };
  }

  async searchStocks(query: string): Promise<Stock[]> {
    if (!query) return [];
    
    return WATCHLIST_STOCKS.filter(
      stock => stock.symbol.toLowerCase().includes(query.toLowerCase()) || 
               stock.companyName.toLowerCase().includes(query.toLowerCase())
    );
  }
  
  // Options data methods
  async getOptionChain(symbol: string, expiryDate: string): Promise<OptionChainList | undefined> {
    // Check if the stock exists - handle both NIFTY and NIFTY 50
    const stock = WATCHLIST_STOCKS.find(s => 
      s.symbol === symbol || 
      (symbol === "NIFTY" && s.symbol === "NIFTY 50") ||
      (symbol === "NIFTY 50" && s.symbol === "NIFTY")
    );
    
    if (!stock) return undefined;
    
    // Normalize the symbol for NIFTY/NIFTY 50 cases
    const normalizedSymbol = (symbol === "NIFTY 50") ? "NIFTY" : symbol;
    
    const spotPrice = stock.ltp;
    const lastUpdated = new Date().toISOString();
    
    // Generate strike prices around the spot price
    // For indices like NIFTY and BANKNIFTY, use increments of 50 points
    // For regular stocks, use appropriate increments based on price
    let increment = 10;
    
    if (normalizedSymbol === 'NIFTY') {
      increment = 50;
    } else if (normalizedSymbol === 'BANKNIFTY') {
      increment = 100;
    } else if (spotPrice > 1000) {
      increment = 20;
    } else if (spotPrice > 500) {
      increment = 10;
    } else if (spotPrice > 100) {
      increment = 5;
    } else {
      increment = 2.5;
    }
    
    const baseStrikePrice = Math.round(spotPrice / increment) * increment;
    const strikePrices = [];
    
    // Generate more strike prices for better range
    for (let i = -15; i <= 15; i++) {
      strikePrices.push(baseStrikePrice + (i * increment));
    }
    
    // Parse expiry date to calculate time to expiry
    const [day, month, year] = expiryDate.split('-');
    const expiryDateObj = new Date(`${month}-${day}-${year}`);
    const currentDate = new Date();
    const daysToExpiry = Math.max(1, Math.ceil((expiryDateObj.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24)));
    const timeToExpiryFactor = Math.min(0.5, daysToExpiry / 365);
    
    // Generate option chain data
    const options = strikePrices.map(strikePrice => {
      const callITM = spotPrice > strikePrice;
      const putITM = spotPrice < strikePrice;
      
      // Generate reasonable option prices based on strike price, spot price, and time to expiry
      const strikeDiff = Math.abs(spotPrice - strikePrice);
      const distanceFromSpot = strikeDiff / spotPrice;
      const atTheMoneyFactor = Math.exp(-Math.pow(distanceFromSpot * 10, 2));
      
      let callPrice, putPrice;
      
      if (callITM) {
        // In-the-money call
        callPrice = Math.max(0.05, (spotPrice - strikePrice) + (spotPrice * 0.05 * timeToExpiryFactor * (1 + atTheMoneyFactor)));
        // Out-of-the-money put
        putPrice = Math.max(0.05, spotPrice * 0.03 * timeToExpiryFactor * (1 + distanceFromSpot));
      } else {
        // Out-of-the-money call
        callPrice = Math.max(0.05, spotPrice * 0.03 * timeToExpiryFactor * (1 + distanceFromSpot));
        // In-the-money put
        putPrice = Math.max(0.05, (strikePrice - spotPrice) + (spotPrice * 0.05 * timeToExpiryFactor * (1 + atTheMoneyFactor)));
      }
      
      // Add some randomness
      callPrice *= (0.97 + Math.random() * 0.06);
      putPrice *= (0.97 + Math.random() * 0.06);
      
      // Generate changes - more volatile near the money
      const volatilityFactor = Math.max(0.5, atTheMoneyFactor * 2);
      const callChange = (Math.random() * 2 - 1) * callPrice * 0.05 * volatilityFactor;
      const putChange = (Math.random() * 2 - 1) * putPrice * 0.05 * volatilityFactor;
      
      // Calculate percentage changes
      const callChangePercent = callPrice > 0 ? (callChange / callPrice) * 100 : 0;
      const putChangePercent = putPrice > 0 ? (putChange / putPrice) * 100 : 0;
      
      // Generate open interest - higher near ATM
      const baseOI = normalizedSymbol === 'NIFTY' ? 500000 : 100000;
      const oi = Math.floor(baseOI * (0.1 + atTheMoneyFactor * 0.9));
      
      // Volume is a percentage of OI
      const volume = Math.floor(oi * (0.1 + Math.random() * 0.4));
      
      // Implied volatility is higher for OTM options
      const iv = 15 + Math.abs(distanceFromSpot * 100);
      
      return {
        strikePrice,
        callPrice: parseFloat(callPrice.toFixed(2)),
        callChange: parseFloat(callChange.toFixed(2)),
        callChangePercent: parseFloat(callChangePercent.toFixed(2)),
        putPrice: parseFloat(putPrice.toFixed(2)),
        putChange: parseFloat(putChange.toFixed(2)),
        putChangePercent: parseFloat(putChangePercent.toFixed(2)),
        oi,
        volume,
        iv: parseFloat(iv.toFixed(2))
      };
    });
    
    return {
      symbol: normalizedSymbol,
      expiryDate,
      spotPrice,
      lastUpdated,
      options
    };
  }
  
  async getExpiryDates(symbol: string): Promise<string[]> {
    // Check if the stock exists - handle both NIFTY and NIFTY 50
    const stock = WATCHLIST_STOCKS.find(s => 
      s.symbol === symbol || 
      (symbol === "NIFTY" && s.symbol === "NIFTY 50") ||
      (symbol === "NIFTY 50" && s.symbol === "NIFTY")
    );
    
    if (!stock) return [];
    
    // Hard-coded expiry dates for demonstration
    // In real app, these would come from the market data provider
    // Format: DD-MMM-YYYY (e.g., 28-Mar-2025)
    const dates = [
      "04-Apr-2025", // Current week
      "11-Apr-2025", // Next week
      "18-Apr-2025", 
      "25-Apr-2025",
      "30-Apr-2025", // Month-end April
      "09-May-2025",
      "16-May-2025",
      "23-May-2025",
      "30-May-2025", // Month-end May  
      "06-Jun-2025",
      "13-Jun-2025",
      "20-Jun-2025",
      "27-Jun-2025", // Month-end June
      "26-Sep-2025", // Quarterly
      "26-Dec-2025", // Quarterly
      "26-Mar-2026"  // Quarterly
    ];
    
    return dates;
  }

  // Watchlist methods
  async getWatchlists(userId: number): Promise<Watchlist[]> {
    return Array.from(this.watchlists.values()).filter(
      watchlist => watchlist.userId === userId
    );
  }

  async createWatchlist(watchlist: InsertWatchlist): Promise<Watchlist> {
    const id = this.watchlistId++;
    const newWatchlist: Watchlist = { ...watchlist, id };
    this.watchlists.set(id, newWatchlist);
    return newWatchlist;
  }

  async getWatchlistItems(watchlistId: number): Promise<Stock[]> {
    const items = Array.from(this.watchlistItems.values()).filter(
      item => item.watchlistId === watchlistId
    );
    
    return items.map(item => {
      const stock = WATCHLIST_STOCKS.find(s => s.symbol === item.symbol);
      if (!stock) {
        // If not found, return a default stock
        return {
          symbol: item.symbol,
          companyName: item.companyName,
          ltp: 0,
          change: 0,
          percentageChange: 0,
          high: 0,
          low: 0,
          volume: "0"
        };
      }
      return stock;
    });
  }

  async addToWatchlist(item: InsertWatchlistItem): Promise<WatchlistItem> {
    const id = this.watchlistItemId++;
    const newItem: WatchlistItem = { ...item, id };
    this.watchlistItems.set(id, newItem);
    return newItem;
  }

  async removeFromWatchlist(watchlistId: number, itemId: number): Promise<void> {
    this.watchlistItems.delete(itemId);
  }

  // Portfolio methods
  async getHoldings(userId: number): Promise<Holding[]> {
    const userHoldings = Array.from(this.holdings.values()).filter(
      holding => holding.userId === userId
    );
    
    return userHoldings.map(holding => {
      const stock = WATCHLIST_STOCKS.find(s => s.symbol === holding.symbol);
      const currentPrice = stock?.ltp || holding.averagePrice;
      const currentValue = holding.quantity * currentPrice;
      const investmentValue = holding.quantity * holding.averagePrice;
      const pnl = currentValue - investmentValue;
      const pnlPercentage = (pnl / investmentValue) * 100;
      
      return {
        ...holding,
        currentPrice,
        currentValue,
        pnl,
        pnlPercentage
      };
    });
  }

  async getPortfolioSummary(userId: number): Promise<{
    currentValue: number;
    investedValue: number;
    totalPnl: number;
    totalPnlPercentage: number;
    availableMargin: number;
  }> {
    const holdings = await this.getHoldings(userId);
    
    const currentValue = holdings.reduce((sum, holding) => {
      return sum + (holding.currentValue ?? 0);
    }, 0);
    
    const investedValue = holdings.reduce((sum, holding) => {
      return sum + (holding.quantity * holding.averagePrice);
    }, 0);
    
    const totalPnl = currentValue - investedValue;
    const totalPnlPercentage = investedValue > 0 ? (totalPnl / investedValue) * 100 : 0;
    const availableMargin = await this.getAvailableMargin(userId);
    
    return {
      currentValue,
      investedValue,
      totalPnl,
      totalPnlPercentage,
      availableMargin
    };
  }

  // Order methods
  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getRecentOrders(userId: number, limit: number): Promise<Order[]> {
    return (await this.getOrders(userId)).slice(0, limit);
  }

  async placeOrder(order: InsertOrder): Promise<Order> {
    const id = this.orderId++;
    const newOrder: Order = { 
      ...order, 
      id,
      createdAt: new Date() 
    };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  // Helper methods
  private generateChartData(period: string): ChartData[] {
    const data: ChartData[] = [];
    const now = new Date();
    let points = 0;
    let timeIncrement = 0;
    
    switch(period) {
      case "1d":
        points = 78; // 390 minutes (6.5 hours) / 5 minutes per point
        timeIncrement = 5 * 60 * 1000; // 5 minutes in milliseconds
        break;
      case "1w":
        points = 7;
        timeIncrement = 24 * 60 * 60 * 1000; // 1 day in milliseconds
        break;
      case "1m":
        points = 30;
        timeIncrement = 24 * 60 * 60 * 1000; // 1 day in milliseconds
        break;
      case "1y":
        points = 12;
        timeIncrement = 30 * 24 * 60 * 60 * 1000; // 1 month in milliseconds
        break;
      case "all":
        points = 24;
        timeIncrement = 30 * 24 * 60 * 60 * 1000; // 1 month in milliseconds
        break;
      default:
        points = 78;
        timeIncrement = 5 * 60 * 1000;
    }
    
    const basePrice = 2380 + Math.random() * 20;
    let lastPrice = basePrice;
    
    // Generate points
    for (let i = points - 1; i >= 0; i--) {
      const time = new Date(now.getTime() - (i * timeIncrement));
      
      // Random walk with mean reversion
      const change = (Math.random() - 0.5) * 5;
      const meanReversion = (basePrice - lastPrice) * 0.05;
      lastPrice = lastPrice + change + meanReversion;
      
      data.push({
        time: time.toISOString(),
        price: lastPrice
      });
    }
    
    return data;
  }
}

// Import the AngelOneStorage
import { AngelOneStorage } from './services/angelOneStorage';

// Use Angel One storage instead of memory storage
export const storage = new AngelOneStorage();
