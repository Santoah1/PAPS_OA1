import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { DataTable } from "@/components/ui/data-table";
import { useQuery } from "@tanstack/react-query";
import { getWatchlists, getWatchlistItems } from "@/lib/api";
import { formatCurrency, getPriceChangeClass } from "@/lib/utils";
import { Plus, RefreshCw } from "lucide-react";
import { ColumnDef } from "@tanstack/react-table";
import { Stock } from "@shared/schema";
import { WATCHLIST_STOCKS } from "@/lib/constants";

const Watchlist: React.FC = () => {
  const [selectedWatchlistId, setSelectedWatchlistId] = useState<number>(1);

  const { data: watchlists, isLoading: isLoadingWatchlists } = useQuery({
    queryKey: ['/api/watchlists'],
    staleTime: 300000, // 5 minutes
  });

  const { data: watchlistItems, isLoading: isLoadingItems, refetch } = useQuery({
    queryKey: [`/api/watchlists/${selectedWatchlistId}/items`],
    staleTime: 60000, // 1 minute
    refetchInterval: 30000, // Refresh every 30 seconds
    enabled: !!selectedWatchlistId,
  });

  const handleRefresh = () => {
    refetch();
  };

  const columns: ColumnDef<Stock>[] = [
    {
      accessorKey: "symbol",
      header: "Symbol",
      cell: ({ row }) => (
        <div>
          <div className="font-medium">{row.original.symbol}</div>
          <div className="text-xs text-mid-gray">{row.original.companyName}</div>
        </div>
      ),
      meta: {
        className: "p-3 text-left"
      }
    },
    {
      accessorKey: "ltp",
      header: "LTP",
      cell: ({ row }) => (
        <div className="font-medium">{formatCurrency(row.original.ltp)}</div>
      ),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "change",
      header: "Chg.",
      cell: ({ row }) => (
        <div className={getPriceChangeClass(row.original.change)}>
          {row.original.change >= 0 ? "+" : ""}
          {row.original.change.toFixed(2)}
        </div>
      ),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "percentageChange",
      header: "Chg%",
      cell: ({ row }) => (
        <div className={getPriceChangeClass(row.original.percentageChange)}>
          {row.original.percentageChange >= 0 ? "+" : ""}
          {row.original.percentageChange.toFixed(2)}%
        </div>
      ),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "high",
      header: "High",
      cell: ({ row }) => formatCurrency(row.original.high),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "low",
      header: "Low",
      cell: ({ row }) => formatCurrency(row.original.low),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "volume",
      header: "Volume",
      cell: ({ row }) => row.original.volume,
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      id: "actions",
      header: "Action",
      cell: () => (
        <Button size="sm" className="py-1 px-3 bg-primary text-white text-xs rounded hover:bg-dark-blue">
          Trade
        </Button>
      ),
      meta: {
        className: "p-3 text-center"
      }
    },
  ];

  return (
    <Card className="bg-white shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-light-gray">
        <CardTitle className="text-base font-bold">Watchlist</CardTitle>
        <div className="flex items-center">
          <Button 
            variant="ghost" 
            className="p-1 text-mid-gray hover:text-text"
            onClick={handleRefresh}
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button variant="ghost" className="p-1 text-mid-gray hover:text-text ml-2">
            <Plus className="h-4 w-4" />
          </Button>
          <div className="ml-4">
            <Select 
              value={selectedWatchlistId.toString()} 
              onValueChange={(value) => setSelectedWatchlistId(parseInt(value))}
            >
              <SelectTrigger className="text-sm bg-background border border-light-gray rounded px-2 py-1 h-auto w-40">
                <SelectValue placeholder="Select Watchlist" />
              </SelectTrigger>
              <SelectContent>
                {isLoadingWatchlists ? (
                  <SelectItem value="1">Loading...</SelectItem>
                ) : (
                  (watchlists || [{ id: 1, name: "My Watchlist" }]).map((watchlist) => (
                    <SelectItem key={watchlist.id} value={watchlist.id.toString()}>
                      {watchlist.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="overflow-x-auto scrollbar-thin">
          <DataTable 
            columns={columns} 
            data={watchlistItems || WATCHLIST_STOCKS}
            isPending={isLoadingItems}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default Watchlist;
