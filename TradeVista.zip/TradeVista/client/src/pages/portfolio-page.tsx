import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DataTable } from "@/components/ui/data-table";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  Legend 
} from "recharts";
import { useQuery } from "@tanstack/react-query";
import { getHoldings, getPortfolioSummary } from "@/lib/api";
import { formatCurrency, getPriceChangeClass } from "@/lib/utils";
import { PORTFOLIO_HOLDINGS } from "@/lib/constants";
import { ColumnDef } from "@tanstack/react-table";
import { Holding } from "@shared/schema";

const PortfolioPage: React.FC = () => {
  const { data: holdings, isLoading: isLoadingHoldings } = useQuery({
    queryKey: ['/api/portfolio/holdings'],
    staleTime: 60000, // 1 minute
    refetchInterval: 60000, // Refresh every minute
  });

  const { data: summary, isLoading: isLoadingSummary } = useQuery({
    queryKey: ['/api/portfolio/summary'],
    staleTime: 60000, // 1 minute
    refetchInterval: 60000, // Refresh every minute
  });

  const defaultSummary = {
    currentValue: 487235.75,
    investedValue: 474777.45,
    totalPnl: 12458.30,
    totalPnlPercentage: 2.6,
    availableMargin: 125000.00
  };

  const colors = ["#2962FF", "#00C853", "#FF2E63", "#FFC107", "#607D8B"];

  const pieData = React.useMemo(() => {
    const data = holdings || PORTFOLIO_HOLDINGS;
    return data.map((holding) => ({
      name: holding.symbol,
      value: holding.currentValue
    }));
  }, [holdings]);

  const columns: ColumnDef<Holding>[] = [
    {
      accessorKey: "symbol",
      header: "Symbol",
      cell: ({ row }) => (
        <div>
          <div className="font-medium">{row.original.symbol}</div>
          <div className="text-xs text-mid-gray">{row.original.companyName}</div>
        </div>
      ),
      meta: {
        className: "p-3 text-left"
      }
    },
    {
      accessorKey: "quantity",
      header: "Qty",
      cell: ({ row }) => row.original.quantity,
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "averagePrice",
      header: "Avg. Price",
      cell: ({ row }) => formatCurrency(row.original.averagePrice),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "currentPrice",
      header: "LTP",
      cell: ({ row }) => formatCurrency(row.original.currentPrice),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "currentValue",
      header: "Current Value",
      cell: ({ row }) => formatCurrency(row.original.currentValue),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "pnl",
      header: "P&L",
      cell: ({ row }) => (
        <div className={getPriceChangeClass(row.original.pnl)}>
          {row.original.pnl >= 0 ? "+" : ""}
          {formatCurrency(row.original.pnl)}
        </div>
      ),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "pnlPercentage",
      header: "P&L%",
      cell: ({ row }) => (
        <div className={getPriceChangeClass(row.original.pnlPercentage)}>
          {row.original.pnlPercentage >= 0 ? "+" : ""}
          {row.original.pnlPercentage.toFixed(2)}%
        </div>
      ),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      id: "actions",
      header: "Action",
      cell: () => (
        <Button size="sm" className="py-1 px-3 bg-primary text-white text-xs rounded hover:bg-[#1A4CCA]">
          Trade
        </Button>
      ),
      meta: {
        className: "p-3 text-center"
      }
    },
  ];

  return (
    <>
      <div className="mb-6">
        <h1 className="text-xl font-bold mb-4">Portfolio</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-white shadow-sm">
            <CardContent className="p-4">
              <div className="text-sm text-mid-gray mb-1">Current Value</div>
              <div className="text-2xl font-bold">
                {formatCurrency((summary?.currentValue || defaultSummary.currentValue))}
              </div>
              <div className={`text-sm mt-1 ${
                getPriceChangeClass((summary?.totalPnl || defaultSummary.totalPnl))
              }`}>
                {(summary?.totalPnl || defaultSummary.totalPnl) >= 0 ? "+" : ""}
                {formatCurrency((summary?.totalPnl || defaultSummary.totalPnl))} 
                ({(summary?.totalPnlPercentage || defaultSummary.totalPnlPercentage) >= 0 ? "+" : ""}
                {(summary?.totalPnlPercentage || defaultSummary.totalPnlPercentage).toFixed(2)}%)
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white shadow-sm">
            <CardContent className="p-4">
              <div className="text-sm text-mid-gray mb-1">Invested Value</div>
              <div className="text-2xl font-bold">
                {formatCurrency((summary?.investedValue || defaultSummary.investedValue))}
              </div>
              <div className="text-sm mt-1 text-mid-gray">
                Total Investment
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white shadow-sm">
            <CardContent className="p-4">
              <div className="text-sm text-mid-gray mb-1">Available Margin</div>
              <div className="text-2xl font-bold">
                {formatCurrency((summary?.availableMargin || defaultSummary.availableMargin))}
              </div>
              <div className="text-sm mt-1 text-mid-gray">
                Available for trading
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="bg-white shadow-sm mb-6">
        <Tabs defaultValue="holdings">
          <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-light-gray">
            <CardTitle className="font-bold">Portfolio Analysis</CardTitle>
            <TabsList>
              <TabsTrigger value="holdings">Holdings</TabsTrigger>
              <TabsTrigger value="allocation">Allocation</TabsTrigger>
            </TabsList>
          </CardHeader>
          <CardContent className="p-4">
            <TabsContent value="holdings" className="mt-0">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={[
                      { date: "Jan", value: 400000 },
                      { date: "Feb", value: 380000 },
                      { date: "Mar", value: 420000 },
                      { date: "Apr", value: 450000 },
                      { date: "May", value: 470000 },
                      { date: "Jun", value: 487235 }
                    ]}
                    margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#E0E3E7" vertical={false} />
                    <XAxis dataKey="date" tick={{ fontSize: 12, fill: '#8C9099' }} />
                    <YAxis 
                      tickFormatter={(value) => `₹${(value / 1000).toFixed(0)}K`}
                      tick={{ fontSize: 12, fill: '#8C9099' }}
                    />
                    <Tooltip
                      formatter={(value: any) => [formatCurrency(value), "Portfolio Value"]}
                      contentStyle={{ background: 'rgba(30, 35, 41, 0.8)', border: 'none', borderRadius: '4px', color: 'white' }}
                    />
                    <Area type="monotone" dataKey="value" stroke="#2962FF" fill="url(#colorValue)" />
                    <defs>
                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#2962FF" stopOpacity={0.2} />
                        <stop offset="95%" stopColor="#2962FF" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
            <TabsContent value="allocation" className="mt-0">
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                      ))}
                    </Pie>
                    <Legend />
                    <Tooltip 
                      formatter={(value: any) => formatCurrency(value)}
                      contentStyle={{ background: 'rgba(30, 35, 41, 0.8)', border: 'none', borderRadius: '4px', color: 'white' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </TabsContent>
          </CardContent>
        </Tabs>
      </Card>

      <Card className="bg-white shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-light-gray">
          <CardTitle className="font-bold">Current Holdings</CardTitle>
          <Button onClick={() => {}} variant="outline">
            Export
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <DataTable
            columns={columns}
            data={holdings || PORTFOLIO_HOLDINGS}
            isPending={isLoadingHoldings}
            showPagination={true}
          />
        </CardContent>
      </Card>
    </>
  );
};

export default PortfolioPage;
