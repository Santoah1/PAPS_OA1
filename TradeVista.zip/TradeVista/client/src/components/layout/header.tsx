import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, Bell, HelpCircle, User as UserIcon, Search } from "lucide-react";
import Sidebar from "./sidebar";

const Header: React.FC = () => {
  const [searchValue, setSearchValue] = useState("");

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchValue(e.target.value);
  };

  return (
    <header className="bg-white border-b border-light-gray h-16 flex items-center px-4 justify-between">
      <div className="flex items-center md:hidden">
        <Button 
          variant="ghost" 
          size="icon" 
          className="text-text p-2"
          onClick={() => {
            // Force open mobile menu via direct DOM manipulation
            const mobileMenu = document.createElement('div');
            mobileMenu.className = 'fixed inset-0 bg-white z-50 overflow-auto';
            mobileMenu.innerHTML = `
              <div class="p-4 border-b flex justify-between items-center">
                <div class="font-bold">Mr_Santosh_Shah</div>
                <button id="close-menu" class="p-2">✕</button>
              </div>
              <div class="p-4">
                <a href="/" class="block py-3 px-4 border-b">Dashboard</a>
                <a href="/orders" class="block py-3 px-4 border-b">Orders</a>
                <a href="/portfolio" class="block py-3 px-4 border-b">Portfolio</a>
                <a href="/watchlist" class="block py-3 px-4 border-b">Watchlist</a>
                <a href="/market" class="block py-3 px-4 border-b">Market</a>
                <a href="/options" class="block py-3 px-4 border-b">Options Chain</a>
                <a href="/funds" class="block py-3 px-4 border-b">Funds</a>
                <a href="/reports" class="block py-3 px-4 border-b">Reports</a>
                <a href="/settings" class="block py-3 px-4 border-b">Settings</a>
              </div>
            `;
            document.body.appendChild(mobileMenu);
            
            document.getElementById('close-menu')?.addEventListener('click', () => {
              document.body.removeChild(mobileMenu);
            });
            
            // Add click event to all links
            const links = mobileMenu.querySelectorAll('a');
            links.forEach(link => {
              link.addEventListener('click', (e) => {
                e.preventDefault();
                window.location.href = link.getAttribute('href') || '/';
                document.body.removeChild(mobileMenu);
              });
            });
          }}
        >
          <Menu className="h-5 w-5" />
        </Button>
        <div className="ml-2 font-bold">Mr_Santosh_Shah</div>
      </div>
      
      <div className="flex items-center space-x-8 ml-auto">
        <div className="hidden md:flex items-center bg-background rounded-md px-3 py-2 w-64 relative">
          <Search className="text-mid-gray h-4 w-4 mr-2" />
          <Input 
            type="text" 
            placeholder="Search stocks, indices..." 
            className="bg-transparent text-sm border-0 focus-visible:ring-0 focus-visible:ring-offset-0 p-0 h-auto"
            value={searchValue}
            onChange={handleSearchChange}
          />
        </div>
        
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="text-mid-gray hover:text-text p-1">
            <Bell className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-mid-gray hover:text-text p-1">
            <HelpCircle className="h-5 w-5" />
          </Button>
          <div className="md:hidden">
            <Button variant="ghost" size="icon" className="text-text p-1">
              <UserIcon className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
