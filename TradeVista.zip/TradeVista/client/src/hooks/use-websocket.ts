import { useState, useEffect, useRef, useCallback } from 'react';

export interface SocketMessage {
  type: string;
  data: any;
}

export interface WebSocketHook {
  isConnected: boolean;
  error: string | null;
  sendMessage: (message: SocketMessage) => void;
  lastMessage: SocketMessage | null;
  subscribe: (symbols: string[]) => void;
  unsubscribe: (symbols: string[]) => void;
}

export function useWebSocket(): WebSocketHook {
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastMessage, setLastMessage] = useState<SocketMessage | null>(null);
  
  const socketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const reconnectAttemptsRef = useRef(0);
  const MAX_RECONNECT_ATTEMPTS = 5;
  const RECONNECT_INTERVAL = 5000; // 5 seconds
  
  const connectWebSocket = useCallback(() => {
    try {
      // Close existing connection if any
      if (socketRef.current) {
        socketRef.current.close();
      }
      
      // Create WebSocket connection
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/ws`;
      
      const socket = new WebSocket(wsUrl);
      socketRef.current = socket;
      
      socket.onopen = () => {
        console.log('WebSocket connected');
        setIsConnected(true);
        setError(null);
        reconnectAttemptsRef.current = 0;
        
        // Send initial ping to verify connection
        if (socket.readyState === WebSocket.OPEN) {
          socket.send(JSON.stringify({ type: 'ping', data: { timestamp: new Date().toISOString() } }));
        }
      };
      
      socket.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data) as SocketMessage;
          setLastMessage(message);
          
          // Handle connection status updates
          if (message.type === 'status') {
            setIsConnected(message.data.connected);
            if (!message.data.connected && message.data.error) {
              setError(message.data.error);
            }
          }
          
          // Handle errors
          if (message.type === 'error') {
            setError(message.data.message);
          }
          
        } catch (err) {
          console.error('Error parsing WebSocket message:', err);
        }
      };
      
      socket.onerror = (event) => {
        console.error('WebSocket error:', event);
        setError('WebSocket connection error');
        setIsConnected(false);
      };
      
      socket.onclose = () => {
        console.log('WebSocket disconnected');
        setIsConnected(false);
        
        // Attempt to reconnect if disconnected unexpectedly
        if (reconnectAttemptsRef.current < MAX_RECONNECT_ATTEMPTS) {
          reconnectAttemptsRef.current++;
          
          console.log(`WebSocket reconnecting in ${RECONNECT_INTERVAL}ms (Attempt ${reconnectAttemptsRef.current})`);
          
          reconnectTimeoutRef.current = setTimeout(() => {
            connectWebSocket();
          }, RECONNECT_INTERVAL);
        } else {
          setError('Maximum reconnection attempts reached. Please refresh the page.');
        }
      };
      
    } catch (err) {
      console.error('Failed to connect to WebSocket:', err);
      setError('Failed to establish WebSocket connection');
      setIsConnected(false);
    }
  }, []);
  
  // Initialize WebSocket connection
  useEffect(() => {
    connectWebSocket();
    
    // Cleanup on unmount
    return () => {
      if (socketRef.current) {
        socketRef.current.close();
      }
      
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
    };
  }, [connectWebSocket]);
  
  // Handle page visibility changes to reconnect if needed
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && !isConnected) {
        connectWebSocket();
      }
    };
    
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [connectWebSocket, isConnected]);
  
  // Send message to the server
  const sendMessage = useCallback((message: SocketMessage) => {
    if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
      try {
        socketRef.current.send(JSON.stringify(message));
      } catch (err) {
        console.error('Error sending WebSocket message:', err);
        setError('Failed to send message');
      }
    } else {
      setError('WebSocket not connected');
    }
  }, []);
  
  // Subscribe to symbols
  const subscribe = useCallback((symbols: string[]) => {
    if (symbols.length === 0) return;
    
    sendMessage({
      type: 'subscribe',
      data: { symbols }
    });
  }, [sendMessage]);
  
  // Unsubscribe from symbols
  const unsubscribe = useCallback((symbols: string[]) => {
    if (symbols.length === 0) return;
    
    sendMessage({
      type: 'unsubscribe',
      data: { symbols }
    });
  }, [sendMessage]);
  
  return {
    isConnected,
    error,
    sendMessage,
    lastMessage,
    subscribe,
    unsubscribe
  };
}

// Hook to get real-time updates for a specific symbol
export function useSymbolWebSocket(symbol: string): {
  data: any | null;
  isLoading: boolean;
  error: string | null;
} {
  const { isConnected, error, lastMessage, subscribe, unsubscribe } = useWebSocket();
  const [data, setData] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Subscribe to symbol updates when connected
  useEffect(() => {
    if (isConnected && symbol) {
      subscribe([symbol]);
      setIsLoading(true);
      
      // Cleanup: unsubscribe when unmounting
      return () => {
        unsubscribe([symbol]);
      };
    }
  }, [isConnected, symbol, subscribe, unsubscribe]);
  
  // Process incoming messages
  useEffect(() => {
    if (lastMessage && lastMessage.type === 'tick' && lastMessage.data.symbol === symbol) {
      setData(lastMessage.data);
      setIsLoading(false);
    }
  }, [lastMessage, symbol]);
  
  return { data, isLoading, error };
}

// Hook to get real-time updates for multiple symbols
export function useMultiSymbolWebSocket(symbols: string[]): {
  data: Record<string, any>;
  isLoading: boolean;
  error: string | null;
} {
  const { isConnected, error, lastMessage, subscribe, unsubscribe } = useWebSocket();
  const [data, setData] = useState<Record<string, any>>({});
  const [isLoading, setIsLoading] = useState(true);
  
  // Subscribe to symbol updates when connected
  useEffect(() => {
    if (isConnected && symbols.length > 0) {
      subscribe(symbols);
      setIsLoading(true);
      
      // Cleanup: unsubscribe when unmounting
      return () => {
        unsubscribe(symbols);
      };
    }
  }, [isConnected, symbols, subscribe, unsubscribe]);
  
  // Process incoming messages
  useEffect(() => {
    if (lastMessage && lastMessage.type === 'tick' && symbols.includes(lastMessage.data.symbol)) {
      setData(prevData => ({
        ...prevData,
        [lastMessage.data.symbol]: lastMessage.data
      }));
      setIsLoading(false);
    }
  }, [lastMessage, symbols]);
  
  return { data, isLoading, error };
}