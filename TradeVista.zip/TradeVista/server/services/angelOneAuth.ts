import { authenticator } from 'otplib';
import { SmartAPI } from 'smartapi-javascript';

// TOTP Generator for Angel One login
export function generateTOTP(secret: string): string {
  try {
    // Generate TOTP using the provided secret
    return authenticator.generate(secret);
  } catch (error) {
    console.error('Error generating TOTP:', error);
    throw new Error('Failed to generate TOTP token');
  }
}

// Angel One API Authentication Service
export class AngelOneAuthService {
  private smartApi: any;
  private jwtToken: string | null = null;
  private refreshToken: string | null = null;
  private feedToken: string | null = null;
  private isLoggedIn: boolean = false;
  private tokenExpiry: Date | null = null;

  constructor() {
    // Initialize the SmartAPI SDK
    this.smartApi = new SmartAPI({
      api_key: process.env.ANGEL_MARKET_API_KEY || ''
    });
  }

  // Login to Angel One API
  async login(): Promise<{
    isLoggedIn: boolean;
    jwtToken?: string;
    feedToken?: string;
    message?: string;
  }> {
    try {
      if (this.isLoggedIn && this.tokenExpiry && this.tokenExpiry > new Date()) {
        return {
          isLoggedIn: true,
          jwtToken: this.jwtToken || undefined,
          feedToken: this.feedToken || undefined
        };
      }

      // Check if we have all required credentials
      if (!process.env.ANGEL_CLIENT_ID || 
          !process.env.ANGEL_PASSWORD || 
          !process.env.ANGEL_TOTP_SECRET) {
        throw new Error('Missing Angel One API credentials');
      }

      // Generate TOTP for login
      const totp = generateTOTP(process.env.ANGEL_TOTP_SECRET);

      // Login to Angel One
      const loginResponse = await this.smartApi.generateSession(
        process.env.ANGEL_CLIENT_ID,
        process.env.ANGEL_PASSWORD,
        totp
      );

      // Check if login was successful
      if (loginResponse && loginResponse.data) {
        this.jwtToken = loginResponse.data.jwtToken;
        this.refreshToken = loginResponse.data.refreshToken;
        this.feedToken = loginResponse.data.feedToken;
        this.isLoggedIn = true;
        
        // Set token expiry to 6 hours from now
        this.tokenExpiry = new Date();
        this.tokenExpiry.setHours(this.tokenExpiry.getHours() + 6);

        return {
          isLoggedIn: true,
          jwtToken: this.jwtToken,
          feedToken: this.feedToken
        };
      } else {
        throw new Error('Login response not valid');
      }
    } catch (error: any) {
      console.error('Angel One login error:', error);
      return {
        isLoggedIn: false,
        message: error.message || 'Failed to login to Angel One API'
      };
    }
  }

  // Refresh the JWT token
  async refreshSession(): Promise<boolean> {
    try {
      if (!this.refreshToken) {
        throw new Error('No refresh token available');
      }

      const refreshResponse = await this.smartApi.generateAccessTokenFromRefreshToken(
        process.env.ANGEL_CLIENT_ID || '',
        this.refreshToken
      );

      if (refreshResponse && refreshResponse.data) {
        this.jwtToken = refreshResponse.data.jwtToken;
        this.isLoggedIn = true;
        
        // Reset token expiry
        this.tokenExpiry = new Date();
        this.tokenExpiry.setHours(this.tokenExpiry.getHours() + 6);
        
        return true;
      } else {
        throw new Error('Token refresh failed');
      }
    } catch (error) {
      console.error('Angel One token refresh error:', error);
      this.isLoggedIn = false;
      return false;
    }
  }

  // Get the JWT token for API calls
  async getJwtToken(): Promise<string> {
    if (!this.isLoggedIn || !this.jwtToken) {
      const loginResult = await this.login();
      if (!loginResult.isLoggedIn || !loginResult.jwtToken) {
        throw new Error('Failed to get JWT token');
      }
      return loginResult.jwtToken;
    }

    // Check if token is about to expire
    if (this.tokenExpiry && this.tokenExpiry < new Date()) {
      const refreshed = await this.refreshSession();
      if (!refreshed || !this.jwtToken) {
        const loginResult = await this.login();
        if (!loginResult.isLoggedIn || !loginResult.jwtToken) {
          throw new Error('Failed to refresh JWT token');
        }
        return loginResult.jwtToken;
      }
    }

    return this.jwtToken;
  }

  // Get the feed token for websocket connections
  async getFeedToken(): Promise<string> {
    if (!this.isLoggedIn || !this.feedToken) {
      const loginResult = await this.login();
      if (!loginResult.isLoggedIn || !loginResult.feedToken) {
        throw new Error('Failed to get feed token');
      }
      return loginResult.feedToken;
    }
    return this.feedToken;
  }

  // Logout from Angel One API
  async logout(): Promise<boolean> {
    try {
      if (this.isLoggedIn && this.jwtToken) {
        await this.smartApi.logout();
        this.jwtToken = null;
        this.refreshToken = null;
        this.feedToken = null;
        this.isLoggedIn = false;
        this.tokenExpiry = null;
      }
      return true;
    } catch (error) {
      console.error('Angel One logout error:', error);
      return false;
    }
  }

  // Get SmartAPI instance with JWT token
  async getSmartApiInstance(): Promise<any> {
    await this.getJwtToken(); // Ensure we have a valid token
    return this.smartApi;
  }
}

// Singleton instance
export const angelOneAuthService = new AngelOneAuthService();