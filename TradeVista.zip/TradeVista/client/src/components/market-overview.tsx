import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { getMarketIndices } from "@/lib/api";
import { formatCurrency, getPriceChangeClass } from "@/lib/utils";
import { MARKET_INDICES } from "@/lib/constants";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, TrendingDown, Clock } from "lucide-react";

const MarketOverview: React.FC = () => {
  const { data: indices, isLoading } = useQuery({
    queryKey: ['/api/market/indices'],
    staleTime: 60000, // 1 minute before it becomes stale
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const currentTime = new Date();
  const formattedTime = currentTime.toLocaleTimeString('en-US', { 
    hour: '2-digit', 
    minute: '2-digit',
    hour12: true 
  });

  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-xl font-bold">Market Indices</h1>
        <div className="flex items-center text-mid-gray text-sm">
          <Clock className="h-4 w-4 mr-1" />
          <span>Last updated: {formattedTime}</span>
        </div>
      </div>
      
      <div className="overflow-x-auto">
        <div className="flex space-x-4 pb-2">
          {isLoading ? (
            Array.from({length: 4}).map((_, index: number) => (
              <Card key={index} className="bg-white shadow-sm min-w-[240px]">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <Skeleton className="h-5 w-24 mb-2" />
                      <Skeleton className="h-8 w-32" />
                    </div>
                    <div className="text-right">
                      <Skeleton className="h-5 w-16 mb-1" />
                      <Skeleton className="h-4 w-12" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            ((indices as any[]) || MARKET_INDICES).map((index: any) => (
              <Card key={index.id} className="bg-white shadow-sm min-w-[240px] hover:shadow transition-shadow">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-mid-gray text-sm">{index.name}</h3>
                      <p className="text-xl font-bold mt-1">
                        {formatCurrency(index.value).replace('₹', '')}
                      </p>
                    </div>
                    <div className="text-right flex flex-col items-end">
                      <div className={`flex items-center ${getPriceChangeClass(index.change)} font-medium text-sm`}>
                        {index.percentageChange >= 0 ? 
                          <TrendingUp className="h-4 w-4 mr-1" /> : 
                          <TrendingDown className="h-4 w-4 mr-1" />
                        }
                        <span>
                          {index.percentageChange >= 0 ? '+' : ''}
                          {index.percentageChange.toFixed(2)}%
                        </span>
                      </div>
                      <p className={`text-xs ${getPriceChangeClass(index.change)}`}>
                        {index.change >= 0 ? '+' : ''}
                        {index.change.toFixed(2)} pts
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default MarketOverview;
