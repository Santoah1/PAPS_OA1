import React, { useState, useEffect } from 'react';
import OptionChain from '@/components/option-chain';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Loader2, Search, Clock } from "lucide-react";
import { useQuery } from '@tanstack/react-query';
import { searchStocks } from '@/lib/api';
import { CHART_PERIODS } from '@/lib/constants';

export default function OptionChainPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSymbol, setSelectedSymbol] = useState('NIFTY');
  const [refreshInterval, setRefreshInterval] = useState(10000); // Default 10 seconds
  
  // Search for stocks
  const {
    data: searchResults,
    isLoading: isSearching,
    refetch: refetchSearch,
  } = useQuery({
    queryKey: ['/api/market/search', searchQuery],
    queryFn: () => searchStocks(searchQuery),
    enabled: searchQuery.length >= 2,
  });
  
  const handleSearch = () => {
    if (searchQuery.length >= 2) {
      refetchSearch();
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };
  
  const handleSelectStock = (symbol: string) => {
    setSelectedSymbol(symbol);
    setSearchQuery('');
  };
  
  const refreshIntervalOptions = [
    { value: '0', label: 'Manual' },
    { value: '5000', label: '5 seconds' },
    { value: '10000', label: '10 seconds' },
    { value: '30000', label: '30 seconds' },
    { value: '60000', label: '1 minute' },
  ];
  
  return (
    <div className="container px-4 py-6 mx-auto max-w-7xl">
      <div className="flex flex-col gap-6">
        <div className="flex flex-col md:flex-row justify-between gap-4">
          <div className="flex-1">
            <h1 className="text-2xl font-bold">Options Chain</h1>
            <p className="text-muted-foreground">View option chain data for stocks and indices</p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-3 md:w-2/3">
            <div className="relative flex-1">
              <Input
                type="text"
                placeholder="Search for a stock or index..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                className="w-full"
              />
              <Button 
                size="icon" 
                variant="ghost" 
                className="absolute right-0 top-0 h-full"
                onClick={handleSearch}
                disabled={isSearching}
              >
                {isSearching ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Search className="h-4 w-4" />
                )}
              </Button>
              
              {searchQuery.length >= 2 && searchResults && searchResults.length > 0 && (
                <div className="absolute z-10 w-full mt-1 bg-card rounded-md shadow-lg border">
                  <ul className="max-h-80 overflow-auto py-1">
                    {searchResults.map((stock) => (
                      <li 
                        key={stock.symbol}
                        className="px-3 py-2 hover:bg-accent cursor-pointer flex justify-between"
                        onClick={() => handleSelectStock(stock.symbol)}
                      >
                        <div className="font-medium">{stock.symbol}</div>
                        <div className="text-sm text-muted-foreground">{stock.companyName}</div>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground whitespace-nowrap">Auto Refresh:</span>
              </div>
              <Select
                value={refreshInterval.toString()}
                onValueChange={(value) => setRefreshInterval(parseInt(value))}
              >
                <SelectTrigger className="h-10 w-[120px]">
                  <SelectValue placeholder="Select" />
                </SelectTrigger>
                <SelectContent>
                  {refreshIntervalOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
        
        {/* Display the option chain */}
        <div>
          {selectedSymbol ? (
            <OptionChain 
              symbol={selectedSymbol} 
              refreshInterval={refreshInterval} 
            />
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>No Symbol Selected</CardTitle>
                <CardDescription>
                  Search and select a stock or index to view its option chain
                </CardDescription>
              </CardHeader>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}