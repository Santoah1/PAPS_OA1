import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { placeOrder, getAvailableMargin, searchStocks } from "@/lib/api";
import { formatCurrency } from "@/lib/utils";
import { ORDER_TYPES, TRANSACTION_TYPES } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { Search, ArrowRight, Plus, Minus, AlertCircle, Info, Settings, ChevronDown } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface TradingPanelProps {
  defaultSymbol?: string;
}

const TradingPanel: React.FC<TradingPanelProps> = ({ defaultSymbol = "" }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [transactionType, setTransactionType] = useState<"buy" | "sell">("buy");
  const [symbol, setSymbol] = useState(defaultSymbol);
  const [orderType, setOrderType] = useState("limit");
  const [quantity, setQuantity] = useState(10);
  const [price, setPrice] = useState(0);
  const [searchQuery, setSearchQuery] = useState(defaultSymbol);
  const [orderValue, setOrderValue] = useState(0);
  const [productType, setProductType] = useState("nrml");

  const { data: marginData } = useQuery({
    queryKey: ['/api/user/margin'],
    staleTime: 300000, // 5 minutes
  });

  const { data: stockSearchResults, isLoading: isSearching } = useQuery({
    queryKey: [`/api/market/search`, searchQuery],
    enabled: searchQuery.length > 1,
    staleTime: 60000, // 1 minute
  });

  const orderMutation = useMutation({
    mutationFn: placeOrder,
    onSuccess: () => {
      toast({
        title: "Order placed successfully",
        description: `${transactionType.toUpperCase()} order for ${quantity} ${symbol} shares placed.`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
      queryClient.invalidateQueries({ queryKey: ['/api/orders/recent'] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to place order",
        description: error.message || "An error occurred while placing your order",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (symbol && quantity && price) {
      setOrderValue(quantity * price);
    } else {
      setOrderValue(0);
    }
  }, [symbol, quantity, price]);

  const handleSymbolChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSymbol(e.target.value);
    setSearchQuery(e.target.value);
  };

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0) {
      setQuantity(value);
    }
  };

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (!isNaN(value) && value > 0) {
      setPrice(value);
    }
  };

  const incrementQuantity = () => {
    setQuantity(prev => prev + 1);
  };

  const decrementQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!symbol) {
      toast({
        title: "Missing symbol",
        description: "Please enter a valid stock symbol",
        variant: "destructive",
      });
      return;
    }

    if (quantity <= 0) {
      toast({
        title: "Invalid quantity",
        description: "Quantity must be greater than 0",
        variant: "destructive",
      });
      return;
    }

    if (price <= 0 && orderType !== "market") {
      toast({
        title: "Invalid price",
        description: "Price must be greater than 0",
        variant: "destructive",
      });
      return;
    }

    orderMutation.mutate({
      symbol,
      orderType,
      transactionType,
      quantity,
      price: orderType === "market" ? 0 : price,
      productType,
    });
  };

  return (
    <Card className="bg-white shadow-sm">
      <Tabs defaultValue="regular" className="w-full">
        <div className="border-b">
          <TabsList className="w-full grid grid-cols-2 rounded-none bg-transparent h-auto p-0">
            <TabsTrigger 
              value="regular" 
              className="data-[state=active]:border-b-2 data-[state=active]:border-primary 
                        data-[state=active]:text-primary data-[state=active]:shadow-none
                        p-3 font-medium text-base rounded-none"
            >
              Regular
            </TabsTrigger>
            <TabsTrigger 
              value="gtt" 
              className="data-[state=active]:border-b-2 data-[state=active]:border-primary 
                        data-[state=active]:text-primary data-[state=active]:shadow-none 
                        p-3 font-medium text-base rounded-none"
            >
              GTT
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="regular" className="p-0 pt-1">
          <CardContent className="p-4 pt-3">
            <div className="flex flex-col gap-4">
              {/* Transaction Type Tabs */}
              <div className="bg-gray-100 p-1 rounded-lg grid grid-cols-2">
                {TRANSACTION_TYPES.map((type) => (
                  <Button
                    key={type.value}
                    type="button"
                    variant="ghost"
                    className={`rounded-md font-medium text-sm py-2 ${
                      transactionType === type.value 
                        ? type.value === "buy" 
                          ? "bg-green-600 text-white" 
                          : "bg-red-500 text-white"
                        : "bg-transparent text-mid-gray hover:bg-gray-200"
                    }`}
                    onClick={() => setTransactionType(type.value as "buy" | "sell")}
                  >
                    {type.label}
                  </Button>
                ))}
              </div>

              {/* Stock Symbol */}
              <div className="relative rounded-lg border p-3">
                <Label className="absolute -top-2 left-2 bg-white px-1 text-xs text-mid-gray">Stock</Label>
                <div className="flex items-center">
                  <div className="flex-grow relative">
                    <Input 
                      type="text" 
                      value={symbol}
                      onChange={handleSymbolChange}
                      className="border-0 shadow-none focus-visible:ring-0 p-0 text-base font-semibold" 
                      placeholder="Search & add stocks"
                    />
                    <Search className="absolute right-1 top-1 h-5 w-5 text-mid-gray" />
                  </div>
                  {symbol && (
                    <div className="text-xs text-mid-gray px-2 py-1 bg-gray-100 rounded ml-2">
                      NSE
                    </div>
                  )}
                </div>
              </div>

              {/* Product Type Selection */}
              <div className="flex bg-gray-100 p-1 rounded-lg">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className={`rounded-md flex-1 ${productType === 'nrml' ? 'bg-white text-primary shadow-sm' : 'text-mid-gray'}`}
                  onClick={() => setProductType('nrml')}
                >
                  NRML
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className={`rounded-md flex-1 ${productType === 'mis' ? 'bg-white text-primary shadow-sm' : 'text-mid-gray'}`}
                  onClick={() => setProductType('mis')}
                >
                  MIS
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className={`rounded-md flex-1 ${productType === 'cnc' ? 'bg-white text-primary shadow-sm' : 'text-mid-gray'}`}
                  onClick={() => setProductType('cnc')}
                >
                  CNC
                </Button>
              </div>

              {/* Quantity Input */}
              <div className="relative rounded-lg border p-3">
                <Label className="absolute -top-2 left-2 bg-white px-1 text-xs text-mid-gray">Quantity</Label>
                <div className="flex">
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="h-8 w-8 rounded-md"
                    onClick={decrementQuantity}
                  >
                    <Minus className="h-3 w-3" />
                  </Button>
                  <Input 
                    type="number" 
                    value={quantity}
                    onChange={handleQuantityChange}
                    min={1}
                    className="border-0 shadow-none focus-visible:ring-0 text-center font-medium"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="icon"
                    className="h-8 w-8 rounded-md"
                    onClick={incrementQuantity}
                  >
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              {/* Order Type and Price */}
              <div className="relative rounded-lg border p-3">
                <Label className="absolute -top-2 left-2 bg-white px-1 text-xs text-mid-gray">Order Type & Price</Label>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Select value={orderType} onValueChange={setOrderType}>
                      <SelectTrigger className="border-0 shadow-none focus:ring-0 p-0 h-auto">
                        <SelectValue placeholder="Select order type" />
                      </SelectTrigger>
                      <SelectContent>
                        {ORDER_TYPES.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Input 
                      type="number" 
                      value={price}
                      onChange={handlePriceChange}
                      disabled={orderType === "market"}
                      min={0.01}
                      step={0.01}
                      className="border-0 shadow-none focus-visible:ring-0 p-0 text-right font-medium"
                      placeholder={orderType === "market" ? "Market" : "Price"}
                    />
                  </div>
                </div>
              </div>

              {/* Order Value Section */}
              <div className="bg-gray-50 rounded-lg p-3 flex justify-between items-center text-sm">
                <div className="text-mid-gray">Order Value</div>
                <div className="font-semibold">{formatCurrency(orderValue)}</div>
              </div>

              {/* Margin Section */}
              <div className="flex flex-col gap-1">
                <div className="text-xs text-mid-gray flex justify-between">
                  <span>Available Margin</span>
                  <span>{marginData ? formatCurrency(marginData.margin) : "₹0.00"}</span>
                </div>
                <div className="text-xs text-mid-gray flex justify-between">
                  <div className="flex items-center">
                    <span>Required Margin</span>
                    <Info className="h-3 w-3 ml-1 text-mid-gray" />
                  </div>
                  <span>{formatCurrency(orderValue * 0.2)}</span>
                </div>
              </div>

              {/* Action Button */}
              <Button 
                onClick={handleSubmit}
                className={`w-full py-3 rounded-lg font-medium hover:opacity-90 mt-3 ${
                  transactionType === 'buy' 
                    ? 'bg-green-600 text-white' 
                    : 'bg-red-500 text-white'
                }`}
                disabled={orderMutation.isPending}
              >
                {orderMutation.isPending ? "Processing..." : `${transactionType === 'buy' ? 'Buy' : 'Sell'} ${symbol || 'Shares'}`}
              </Button>

              {/* Advanced Settings */}
              <div className="text-primary flex items-center justify-center text-sm cursor-pointer">
                <Settings className="h-3.5 w-3.5 mr-1" />
                <span>Advanced Settings</span>
                <ChevronDown className="h-3.5 w-3.5 ml-1" />
              </div>
            </div>
          </CardContent>
        </TabsContent>

        <TabsContent value="gtt">
          <CardContent className="p-4">
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <AlertCircle className="h-10 w-10 text-mid-gray mb-2" />
              <h3 className="font-medium mb-1">GTT Orders</h3>
              <p className="text-sm text-mid-gray max-w-xs">
                Create Good Till Triggered orders to automatically execute when price conditions are met.
              </p>
              <Button variant="outline" className="mt-4">
                Learn More
              </Button>
            </div>
          </CardContent>
        </TabsContent>
      </Tabs>
    </Card>
  );
};

export default TradingPanel;
