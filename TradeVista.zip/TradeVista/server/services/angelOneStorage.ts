import { IStorage } from '../storage';
import { 
  User, InsertUser, 
  Watchlist, InsertWatchlist, 
  WatchlistItem, InsertWatchlistItem, 
  Holding, InsertHolding, 
  Order, InsertOrder,
  MarketIndex, 
  Stock, 
  UserSettings, InsertUserSettings,
  TradeSuggestion, InsertTradeSuggestion,
  OptionChainList
} from '@shared/schema';
import { angelOneMarketData } from './angelOneMarketData';

// Use Angel One API for market data and keep in-memory storage for other data
export class AngelOneStorage implements IStorage {
  private users: Map<number, User>;
  private watchlists: Map<number, Watchlist>;
  private watchlistItems: Map<number, WatchlistItem>;
  private holdings: Map<number, Holding>;
  private orders: Map<number, Order>;
  private userSettings: Map<number, UserSettings>;
  private tradeSuggestions: Map<number, TradeSuggestion>;

  private userId: number = 1;
  private watchlistId: number = 1;
  private watchlistItemId: number = 1;
  private holdingId: number = 1;
  private orderId: number = 1;
  private userSettingsId: number = 1;
  private tradeSuggestionId: number = 1;

  constructor() {
    this.users = new Map();
    this.watchlists = new Map();
    this.watchlistItems = new Map();
    this.holdings = new Map();
    this.orders = new Map();
    this.userSettings = new Map();
    this.tradeSuggestions = new Map();
    
    this.initializeData();
  }

  private initializeData() {
    // Sample user
    const user: User = {
      id: this.userId,
      username: 'santosh_shah',
      password: 'password',
      email: 'santosh@example.com',
      fullName: 'Santosh Shah',
      createdAt: new Date()
    };
    this.users.set(user.id, user);

    // Sample watchlists
    const watchlist1: Watchlist = {
      id: this.watchlistId++,
      userId: user.id,
      name: 'My Watchlist'
    };
    this.watchlists.set(watchlist1.id, watchlist1);

    const watchlist2: Watchlist = {
      id: this.watchlistId++,
      userId: user.id,
      name: 'Tech Stocks'
    };
    this.watchlists.set(watchlist2.id, watchlist2);

    // Sample watchlist items
    const item1: WatchlistItem = {
      id: this.watchlistItemId++,
      watchlistId: watchlist1.id,
      symbol: 'NIFTY',
      companyName: 'NIFTY 50'
    };
    this.watchlistItems.set(item1.id, item1);

    const item2: WatchlistItem = {
      id: this.watchlistItemId++,
      watchlistId: watchlist1.id,
      symbol: 'RELIANCE',
      companyName: 'Reliance Industries Ltd.'
    };
    this.watchlistItems.set(item2.id, item2);

    const item3: WatchlistItem = {
      id: this.watchlistItemId++,
      watchlistId: watchlist1.id,
      symbol: 'TATASTEEL',
      companyName: 'Tata Steel Ltd.'
    };
    this.watchlistItems.set(item3.id, item3);

    const item4: WatchlistItem = {
      id: this.watchlistItemId++,
      watchlistId: watchlist2.id,
      symbol: 'INFY',
      companyName: 'Infosys Ltd.'
    };
    this.watchlistItems.set(item4.id, item4);

    const item5: WatchlistItem = {
      id: this.watchlistItemId++,
      watchlistId: watchlist2.id,
      symbol: 'TCS',
      companyName: 'Tata Consultancy Services Ltd.'
    };
    this.watchlistItems.set(item5.id, item5);

    // Sample holdings
    const holding1: Holding = {
      id: this.holdingId++,
      userId: user.id,
      symbol: 'RELIANCE',
      companyName: 'Reliance Industries Ltd.',
      quantity: 10,
      avgPrice: 2500.50,
      investedValue: 25005.00
    };
    this.holdings.set(holding1.id, holding1);

    const holding2: Holding = {
      id: this.holdingId++,
      userId: user.id,
      symbol: 'HDFCBANK',
      companyName: 'HDFC Bank Ltd.',
      quantity: 15,
      avgPrice: 1650.25,
      investedValue: 24753.75
    };
    this.holdings.set(holding2.id, holding2);

    const holding3: Holding = {
      id: this.holdingId++,
      userId: user.id,
      symbol: 'INFY',
      companyName: 'Infosys Ltd.',
      quantity: 20,
      avgPrice: 1320.75,
      investedValue: 26415.00
    };
    this.holdings.set(holding3.id, holding3);

    // Sample orders
    const order1: Order = {
      id: this.orderId++,
      userId: user.id,
      symbol: 'RELIANCE',
      companyName: 'Reliance Industries Ltd.',
      orderType: 'LIMIT',
      transactionType: 'BUY',
      quantity: 5,
      price: 2490.00,
      status: 'EXECUTED',
      orderedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      executedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000 + 30 * 60 * 1000) // 30 mins after order
    };
    this.orders.set(order1.id, order1);

    const order2: Order = {
      id: this.orderId++,
      userId: user.id,
      symbol: 'INFY',
      companyName: 'Infosys Ltd.',
      orderType: 'MARKET',
      transactionType: 'BUY',
      quantity: 10,
      price: 1330.50,
      status: 'EXECUTED',
      orderedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
      executedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000 + 15 * 60 * 1000) // 15 mins after order
    };
    this.orders.set(order2.id, order2);

    const order3: Order = {
      id: this.orderId++,
      userId: user.id,
      symbol: 'TCS',
      companyName: 'Tata Consultancy Services Ltd.',
      orderType: 'LIMIT',
      transactionType: 'BUY',
      quantity: 8,
      price: 3512.25,
      status: 'PENDING',
      orderedAt: new Date(Date.now() - 60 * 60 * 1000), // 1 hour ago
      executedAt: null
    };
    this.orders.set(order3.id, order3);

    // Sample user settings
    const settings: UserSettings = {
      id: this.userSettingsId++,
      userId: user.id,
      aiEnabled: true,
      darkMode: false,
      language: 'hi',
      riskTolerance: 'MODERATE',
      aiModel: 'DEFAULT',
      lastUpdated: new Date()
    };
    this.userSettings.set(settings.id, settings);

    // Sample AI trade suggestions
    const suggestion1: TradeSuggestion = {
      id: this.tradeSuggestionId++,
      userId: user.id,
      symbol: 'HDFCBANK',
      action: 'BUY',
      confidence: 0.82,
      riskLevel: 'LOW',
      reason: 'Strong technical indicators with positive momentum',
      targetPrice: 1750.00,
      stopLoss: 1620.00,
      expiryDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000), // 12 hours ago
      isRead: true
    };
    this.tradeSuggestions.set(suggestion1.id, suggestion1);

    const suggestion2: TradeSuggestion = {
      id: this.tradeSuggestionId++,
      userId: user.id,
      symbol: 'TATASTEEL',
      action: 'SELL',
      confidence: 0.65,
      riskLevel: 'MEDIUM',
      reason: 'Potential trend reversal after recent rally',
      targetPrice: 125.00,
      stopLoss: 142.00,
      expiryDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
      createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000), // 4 hours ago
      isRead: true
    };
    this.tradeSuggestions.set(suggestion2.id, suggestion2);

    const suggestion3: TradeSuggestion = {
      id: this.tradeSuggestionId++,
      userId: user.id,
      symbol: 'NIFTY',
      action: 'BUY',
      confidence: 0.78,
      riskLevel: 'MEDIUM',
      reason: 'Positive global cues and strong domestic buying',
      targetPrice: 20500.00,
      stopLoss: 20100.00,
      expiryDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
      createdAt: new Date(),
      isRead: false
    };
    this.tradeSuggestions.set(suggestion3.id, suggestion3);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    for (const user of this.users.values()) {
      if (user.username === username) {
        return user;
      }
    }
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAvailableMargin(userId: number): Promise<number> {
    // In a real app, this would come from the broker API
    return 125000; // Dummy value
  }

  // User Settings methods
  async getUserSettings(userId: number): Promise<UserSettings | undefined> {
    for (const settings of this.userSettings.values()) {
      if (settings.userId === userId) {
        return settings;
      }
    }
    return undefined;
  }

  async createUserSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const id = this.userSettingsId++;
    const newSettings: UserSettings = { 
      ...settings, 
      id, 
      lastUpdated: new Date() 
    };
    this.userSettings.set(id, newSettings);
    return newSettings;
  }

  async updateUserSettings(userId: number, settings: Partial<InsertUserSettings>): Promise<UserSettings> {
    const existingSettings = await this.getUserSettings(userId);
    
    if (!existingSettings) {
      throw new Error('User settings not found');
    }
    
    const updatedSettings: UserSettings = {
      ...existingSettings,
      ...settings,
      lastUpdated: new Date()
    };
    
    this.userSettings.set(existingSettings.id, updatedSettings);
    return updatedSettings;
  }

  async toggleAI(userId: number, enabled: boolean): Promise<UserSettings> {
    return this.updateUserSettings(userId, { aiEnabled: enabled });
  }

  async toggleDarkMode(userId: number, enabled: boolean): Promise<UserSettings> {
    return this.updateUserSettings(userId, { darkMode: enabled });
  }

  // AI Trade Suggestions methods
  async getTradeSuggestions(userId: number, limit?: number): Promise<TradeSuggestion[]> {
    const suggestions = Array.from(this.tradeSuggestions.values())
      .filter(suggestion => suggestion.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return limit ? suggestions.slice(0, limit) : suggestions;
  }

  async createTradeSuggestion(suggestion: InsertTradeSuggestion): Promise<TradeSuggestion> {
    const id = this.tradeSuggestionId++;
    const newSuggestion: TradeSuggestion = {
      ...suggestion,
      id,
      createdAt: new Date(),
      isRead: false
    };
    this.tradeSuggestions.set(id, newSuggestion);
    return newSuggestion;
  }

  async markTradeSuggestionAsRead(suggestionId: number): Promise<void> {
    const suggestion = this.tradeSuggestions.get(suggestionId);
    if (suggestion) {
      suggestion.isRead = true;
      this.tradeSuggestions.set(suggestionId, suggestion);
    }
  }

  // Market data methods - use Angel One API
  async getMarketIndices(): Promise<MarketIndex[]> {
    try {
      // Use Angel One API to get real-time market indices
      return await angelOneMarketData.getMarketIndices();
    } catch (error) {
      console.error('Failed to get market indices from Angel One API:', error);
      // Updated market data as per user's information for March 28, 2025
      const now = new Date();
      return [
        { id: 1, name: 'NIFTY 50', value: 23519.00, change: 168.25, percentageChange: 0.72, updatedAt: now },
        { id: 2, name: 'SENSEX', value: 77342.45, change: 412.80, percentageChange: 0.54, updatedAt: now },
        { id: 3, name: 'NIFTY BANK', value: 52785.20, change: 324.60, percentageChange: 0.62, updatedAt: now },
        { id: 4, name: 'NIFTY IT', value: 37892.60, change: 452.85, percentageChange: 1.21, updatedAt: now },
        { id: 5, name: 'NIFTY MIDCAP 100', value: 54812.35, change: 287.90, percentageChange: 0.53, updatedAt: now }
      ];
    }
  }

  async getStockPrice(symbol: string): Promise<Stock | undefined> {
    try {
      // Use Angel One API to get real-time stock price
      return await angelOneMarketData.getStockPrice(symbol);
    } catch (error) {
      console.error(`Failed to get stock price for ${symbol} from Angel One API:`, error);
      // Fallback to demo data
      return {
        symbol,
        companyName: symbol,
        price: 0,
        change: 0,
        changePercent: 0,
        open: 0,
        high: 0,
        low: 0,
        close: 0,
        volume: 0,
        chartData: []
      };
    }
  }

  async getStockChart(symbol: string, period: string): Promise<Stock | undefined> {
    try {
      // Use Angel One API to get stock chart data
      return await angelOneMarketData.getStockChart(symbol, period);
    } catch (error) {
      console.error(`Failed to get stock chart for ${symbol} from Angel One API:`, error);
      // Fallback to demo data
      return {
        symbol,
        companyName: symbol,
        price: 0,
        change: 0,
        changePercent: 0,
        open: 0,
        high: 0,
        low: 0,
        close: 0,
        volume: 0,
        chartData: []
      };
    }
  }

  async searchStocks(query: string): Promise<Stock[]> {
    try {
      if (!query) {
        throw new Error('Search query is required');
      }
      
      // Use Angel One API to search stocks
      return await angelOneMarketData.searchStocks(query);
    } catch (error) {
      console.error(`Failed to search stocks for ${query} from Angel One API:`, error);
      if (!query) {
        throw new Error('Search query is required');
      }
      // Fallback to demo data
      return [];
    }
  }

  // Options data methods - use Angel One API
  async getOptionChain(symbol: string, expiryDate: string): Promise<OptionChainList | undefined> {
    try {
      // Use Angel One API to get option chain data
      return await angelOneMarketData.getOptionChain(symbol, expiryDate);
    } catch (error) {
      console.error(`Failed to get option chain for ${symbol} from Angel One API:`, error);
      // Return undefined as fallback
      return undefined;
    }
  }

  async getExpiryDates(symbol: string): Promise<string[]> {
    try {
      // Use Angel One API to get expiry dates
      return await angelOneMarketData.getExpiryDates(symbol);
    } catch (error) {
      console.error(`Failed to get expiry dates for ${symbol} from Angel One API:`, error);
      // Return empty array as fallback
      return [];
    }
  }

  // Watchlist methods
  async getWatchlists(userId: number): Promise<Watchlist[]> {
    return Array.from(this.watchlists.values())
      .filter(watchlist => watchlist.userId === userId);
  }

  async createWatchlist(watchlist: InsertWatchlist): Promise<Watchlist> {
    const id = this.watchlistId++;
    const newWatchlist: Watchlist = { ...watchlist, id };
    this.watchlists.set(id, newWatchlist);
    return newWatchlist;
  }

  async getWatchlistItems(watchlistId: number): Promise<Stock[]> {
    const items = Array.from(this.watchlistItems.values())
      .filter(item => item.watchlistId === watchlistId);
    
    const stocks: Stock[] = [];
    
    // Get real-time stock prices for watchlist items
    for (const item of items) {
      try {
        const stock = await this.getStockPrice(item.symbol);
        if (stock) {
          stocks.push(stock);
        }
      } catch (error) {
        console.error(`Failed to get stock price for watchlist item ${item.symbol}:`, error);
        // Add a basic stock object if API call fails
        stocks.push({
          symbol: item.symbol,
          companyName: item.companyName,
          price: 0,
          change: 0,
          changePercent: 0,
          open: 0,
          high: 0,
          low: 0,
          close: 0,
          volume: 0,
          chartData: []
        });
      }
    }
    
    return stocks;
  }

  async addToWatchlist(item: InsertWatchlistItem): Promise<WatchlistItem> {
    const id = this.watchlistItemId++;
    const newItem: WatchlistItem = { ...item, id };
    this.watchlistItems.set(id, newItem);
    return newItem;
  }

  async removeFromWatchlist(watchlistId: number, itemId: number): Promise<void> {
    for (const [id, item] of this.watchlistItems) {
      if (item.watchlistId === watchlistId && item.id === itemId) {
        this.watchlistItems.delete(id);
        return;
      }
    }
  }

  // Portfolio methods
  async getHoldings(userId: number): Promise<Holding[]> {
    const holdings = Array.from(this.holdings.values())
      .filter(holding => holding.userId === userId);
    
    // Get real-time prices and calculate current values
    for (const holding of holdings) {
      try {
        const stock = await this.getStockPrice(holding.symbol);
        if (stock) {
          holding.currentPrice = stock.price;
          holding.currentValue = stock.price * holding.quantity;
          holding.pnl = holding.currentValue - holding.investedValue;
          holding.pnlPercentage = (holding.pnl / holding.investedValue) * 100;
        }
      } catch (error) {
        console.error(`Failed to get current price for holding ${holding.symbol}:`, error);
      }
    }
    
    return holdings;
  }

  async getPortfolioSummary(userId: number): Promise<{
    currentValue: number;
    investedValue: number;
    totalPnl: number;
    totalPnlPercentage: number;
    availableMargin: number;
  }> {
    const holdings = await this.getHoldings(userId);
    
    const investedValue = holdings.reduce((total, holding) => total + holding.investedValue, 0);
    const currentValue = holdings.reduce((total, holding) => {
      return total + (holding.currentValue || 0);
    }, 0);
    
    const totalPnl = currentValue - investedValue;
    const totalPnlPercentage = investedValue > 0 ? (totalPnl / investedValue) * 100 : 0;
    
    const availableMargin = await this.getAvailableMargin(userId);
    
    return {
      currentValue,
      investedValue,
      totalPnl,
      totalPnlPercentage,
      availableMargin
    };
  }

  // Order methods
  async getOrders(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.userId === userId)
      .sort((a, b) => {
        // Sort by orderedAt date, most recent first
        return b.orderedAt.getTime() - a.orderedAt.getTime();
      });
  }

  async getRecentOrders(userId: number, limit: number): Promise<Order[]> {
    const orders = await this.getOrders(userId);
    return orders.slice(0, limit);
  }

  async placeOrder(order: InsertOrder): Promise<Order> {
    const id = this.orderId++;
    
    // In a real app, this would call the broker API to place the order
    const newOrder: Order = { 
      ...order, 
      id,
      status: 'PENDING',
      orderedAt: new Date(),
      executedAt: null
    };
    
    this.orders.set(id, newOrder);
    return newOrder;
  }
}