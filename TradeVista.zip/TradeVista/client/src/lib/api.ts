import axios from 'axios';
import { Stock, MarketIndex, Order, Holding, Watchlist, WatchlistItem, OptionChainList } from '@shared/schema';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Market data endpoints
export const getMarketIndices = async (): Promise<MarketIndex[]> => {
  const response = await api.get('/market/indices');
  return response.data;
};

export const getStockPrice = async (symbol: string): Promise<Stock> => {
  const response = await api.get(`/market/stock/${symbol}`);
  return response.data;
};

export const getStockChart = async (symbol: string, period: string): Promise<Stock> => {
  const response = await api.get(`/market/chart/${symbol}?period=${period}`);
  return response.data;
};

// Watchlist endpoints
export const getWatchlists = async (): Promise<Watchlist[]> => {
  const response = await api.get('/watchlists');
  return response.data;
};

export const getWatchlistItems = async (watchlistId: number): Promise<WatchlistItem[]> => {
  const response = await api.get(`/watchlists/${watchlistId}/items`);
  return response.data;
};

export const addToWatchlist = async (watchlistId: number, symbol: string, companyName: string): Promise<WatchlistItem> => {
  const response = await api.post(`/watchlists/${watchlistId}/items`, { symbol, companyName });
  return response.data;
};

export const removeFromWatchlist = async (watchlistId: number, itemId: number): Promise<void> => {
  await api.delete(`/watchlists/${watchlistId}/items/${itemId}`);
};

export const createWatchlist = async (name: string): Promise<Watchlist> => {
  const response = await api.post('/watchlists', { name });
  return response.data;
};

// Portfolio endpoints
export const getHoldings = async (): Promise<Holding[]> => {
  const response = await api.get('/portfolio/holdings');
  return response.data;
};

export const getPortfolioSummary = async () => {
  const response = await api.get('/portfolio/summary');
  return response.data;
};

// Order endpoints
export const getOrders = async (): Promise<Order[]> => {
  const response = await api.get('/orders');
  return response.data;
};

export const getRecentOrders = async (limit: number = 5): Promise<Order[]> => {
  const response = await api.get(`/orders/recent?limit=${limit}`);
  return response.data;
};

export const placeOrder = async (orderData: { 
  symbol: string; 
  orderType: string; 
  transactionType: string; 
  quantity: number; 
  price: number;
}): Promise<Order> => {
  const response = await api.post('/orders', orderData);
  return response.data;
};

// User endpoints
export const getAvailableMargin = async (): Promise<{margin: number}> => {
  const response = await api.get('/user/margin');
  return response.data;
};

// Search functionality
export const searchStocks = async (query: string): Promise<Stock[]> => {
  const response = await api.get(`/market/search?query=${query}`);
  return response.data;
};

// Option chain endpoints
export const getOptionExpiryDates = async (symbol: string): Promise<string[]> => {
  const response = await api.get(`/options/${symbol}/expiry-dates`);
  return response.data;
};

export const getOptionChain = async (symbol: string, expiryDate: string): Promise<OptionChainList> => {
  const response = await api.get(`/options/${symbol}/chain?expiryDate=${expiryDate}`);
  return response.data;
};
