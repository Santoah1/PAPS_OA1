import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { getStockChart } from "@/lib/api";
import { formatCurrency, getPriceChangeClass } from "@/lib/utils";
import { CHART_PERIODS } from "@/lib/constants";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import { TrendingUp, TrendingDown, Info, Tag } from "lucide-react";

interface StockChartProps {
  symbol: string;
  name?: string;
}

const StockChart: React.FC<StockChartProps> = ({ symbol, name }) => {
  const [period, setPeriod] = useState("1d");
  
  const { data: stock, isLoading } = useQuery({
    queryKey: [`/api/market/chart/${symbol}`, period],
    staleTime: 60000, // 1 minute
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const formatTooltipValue = (value: number) => {
    return `₹${value.toFixed(2)}`;
  };

  const formatXAxis = (tickItem: string) => {
    if (period === "1d") {
      return tickItem.substring(0, 5); // Show only HH:MM
    } else if (period === "1w" || period === "1m") {
      return tickItem.substring(5, 10); // Show only MM-DD
    } else {
      return tickItem.substring(0, 7); // Show only YYYY-MM
    }
  };

  const calculateDomain = (data: any[] | undefined) => {
    if (!data || data.length === 0) return [0, 0];
    
    const prices = data.map(item => item.price);
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    
    // Add 1% buffer to the domain
    const buffer = (max - min) * 0.01;
    return [min - buffer, max + buffer];
  };

  const stockData = stock as any;
  const chartColor = stockData && stockData.change >= 0 ? "#00C853" : "#FF2E63";

  return (
    <Card className="bg-white shadow-sm mb-4">
      <CardContent className="pb-2 pt-3 px-4">
        {isLoading ? (
          <>
            <div className="flex justify-between items-start mb-4">
              <div>
                <Skeleton className="h-6 w-32 mb-2" />
                <Skeleton className="h-8 w-48" />
              </div>
              <div className="flex space-x-2">
                {CHART_PERIODS.map((_, idx) => (
                  <Skeleton key={idx} className="h-8 w-10" />
                ))}
              </div>
            </div>
            <Skeleton className="h-[280px] w-full" />
          </>
        ) : (
          <>
            <div className="flex justify-between items-start mb-4">
              <div>
                <div className="flex items-center">
                  <h2 className="text-lg font-bold">{symbol}</h2>
                  {name && (
                    <div className="flex items-center ml-2">
                      <span className="ml-1 text-xs px-2 py-0.5 bg-gray-100 text-mid-gray rounded">
                        NSE
                      </span>
                      <span className="ml-1 text-xs px-2 py-0.5 border border-gray-200 text-mid-gray rounded">
                        <Tag className="h-3 w-3 mr-1" /> {stockData?.industry || "Equity"}
                      </span>
                    </div>
                  )}
                </div>
                <div className="flex items-center mt-1">
                  <span className="text-xl font-bold mr-3">
                    {stockData ? formatCurrency(stockData.ltp) : ""}
                  </span>
                  {stockData && (
                    <div className={`flex items-center ${getPriceChangeClass(stockData.change)} text-sm font-medium px-2 py-0.5 rounded-sm ${stockData.change >= 0 ? 'bg-green-50' : 'bg-red-50'}`}>
                      {stockData.change >= 0 ? (
                        <TrendingUp className="h-3.5 w-3.5 mr-1" />
                      ) : (
                        <TrendingDown className="h-3.5 w-3.5 mr-1" />
                      )}
                      <span>
                        {(stockData.change || 0) >= 0 ? "+" : ""}
                        {(stockData.change !== undefined && stockData.change !== null) ? stockData.change.toFixed(2) : "0.00"}
                      </span>
                      <span className="mx-1">|</span>
                      <span>
                        {(stockData.percentageChange || 0) >= 0 ? "+" : ""}
                        {(stockData.percentageChange !== undefined && stockData.percentageChange !== null) ? stockData.percentageChange.toFixed(2) : "0.00"}%
                      </span>
                    </div>
                  )}
                </div>
              </div>
              <div className="flex">
                <div className="bg-gray-100 rounded-lg p-1 flex">
                  {CHART_PERIODS.map((chartPeriod) => (
                    <Button
                      key={chartPeriod.value}
                      variant="ghost"
                      size="sm"
                      className={`py-0.5 px-2 text-xs font-medium rounded-md ${
                        period === chartPeriod.value ? 
                        "bg-white text-primary shadow-sm" : 
                        "text-mid-gray hover:bg-gray-200"
                      }`}
                      onClick={() => setPeriod(chartPeriod.value)}
                    >
                      {chartPeriod.label}
                    </Button>
                  ))}
                </div>
                <button className="ml-2 text-mid-gray hover:bg-gray-100 p-1 rounded">
                  <Info className="h-4 w-4" />
                </button>
              </div>
            </div>

            <div className="chart-container h-[280px]">
              {stockData?.data && stockData.data.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={stockData.data}
                    margin={{ top: 10, right: 0, left: 0, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={chartColor} stopOpacity={0.15} />
                        <stop offset="95%" stopColor={chartColor} stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis 
                      dataKey="time" 
                      tickFormatter={formatXAxis}
                      tick={{ fontSize: 11, fill: '#8C9099' }}
                      axisLine={{ stroke: '#E0E3E7' }}
                      tickLine={false}
                      minTickGap={30}
                    />
                    <YAxis 
                      domain={calculateDomain(stockData.data)}
                      tick={{ fontSize: 11, fill: '#8C9099' }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(value) => value.toFixed(0)}
                      orientation="right"
                      width={50}
                    />
                    <CartesianGrid strokeDasharray="3 3" stroke="#E0E3E7" strokeOpacity={0.3} vertical={false} />
                    <Tooltip 
                      formatter={formatTooltipValue}
                      contentStyle={{ 
                        backgroundColor: 'rgba(30, 35, 41, 0.9)', 
                        border: 'none', 
                        borderRadius: '4px',
                        color: 'white',
                        fontSize: '12px',
                        padding: '8px 12px',
                        boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
                      }}
                      labelStyle={{ color: 'white', fontWeight: 'bold', marginBottom: '4px' }}
                    />
                    {stockData && stockData.prevClose && (
                      <ReferenceLine 
                        y={stockData.prevClose} 
                        strokeDasharray="3 3" 
                        stroke="#8C9099" 
                        strokeWidth={1}
                      />
                    )}
                    <Area
                      type="monotone"
                      dataKey="price"
                      stroke={chartColor}
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorPrice)"
                      activeDot={{ r: 6, fill: chartColor, stroke: 'white', strokeWidth: 2 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <p className="text-mid-gray">No chart data available</p>
                </div>
              )}
            </div>

            <div className="flex justify-between mt-1 mb-2 px-1 text-xs text-mid-gray">
              {period === "1d" && (
                <>
                  <div>9:15</div>
                  <div>11:00</div>
                  <div>13:00</div>
                  <div>15:30</div>
                </>
              )}
              {period === "1w" && (
                <>
                  <div>Mon</div>
                  <div>Tue</div>
                  <div>Wed</div>
                  <div>Thu</div>
                  <div>Fri</div>
                </>
              )}
              {period === "1m" && (
                <>
                  <div>Week 1</div>
                  <div>Week 2</div>
                  <div>Week 3</div>
                  <div>Week 4</div>
                </>
              )}
              {period === "3m" && (
                <>
                  <div>Jan</div>
                  <div>Feb</div>
                  <div>Mar</div>
                </>
              )}
              {period === "1y" && (
                <>
                  <div>Q1</div>
                  <div>Q2</div>
                  <div>Q3</div>
                  <div>Q4</div>
                </>
              )}
            </div>
            
            {stockData && (
              <div className="grid grid-cols-3 gap-3 mt-4 border-t border-gray-100 pt-3 text-xs">
                <div>
                  <div className="text-mid-gray">Open</div>
                  <div className="font-medium">{formatCurrency(stockData.open)}</div>
                </div>
                <div>
                  <div className="text-mid-gray">High</div>
                  <div className="font-medium">{formatCurrency(stockData.high)}</div>
                </div>
                <div>
                  <div className="text-mid-gray">Low</div>
                  <div className="font-medium">{formatCurrency(stockData.low)}</div>
                </div>
                <div>
                  <div className="text-mid-gray">Volume</div>
                  <div className="font-medium">{(stockData.volume / 1000).toFixed(2)}K</div>
                </div>
                <div>
                  <div className="text-mid-gray">Prev. Close</div>
                  <div className="font-medium">{formatCurrency(stockData.prevClose)}</div>
                </div>
                <div>
                  <div className="text-mid-gray">52W Range</div>
                  <div className="font-medium">
                    {formatCurrency(stockData.low52w)} - {formatCurrency(stockData.high52w)}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default StockChart;
