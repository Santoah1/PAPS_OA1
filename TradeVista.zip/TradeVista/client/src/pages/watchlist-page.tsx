import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { DataTable } from "@/components/ui/data-table";
import { useQuery } from "@tanstack/react-query";
import { getWatchlists, getWatchlistItems } from "@/lib/api";
import { formatCurrency, getPriceChangeClass } from "@/lib/utils";
import { ColumnDef } from "@tanstack/react-table";
import { Stock } from "@shared/schema";
import { WATCHLIST_STOCKS } from "@/lib/constants";
import { Plus, RefreshCw, Search } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const WatchlistPage: React.FC = () => {
  const [selectedWatchlistId, setSelectedWatchlistId] = React.useState<number>(1);
  const [searchQuery, setSearchQuery] = React.useState("");

  const { data: watchlists, isLoading: isLoadingWatchlists } = useQuery({
    queryKey: ['/api/watchlists'],
    staleTime: 300000, // 5 minutes
  });

  const { data: watchlistItems, isLoading: isLoadingItems, refetch } = useQuery({
    queryKey: [`/api/watchlists/${selectedWatchlistId}/items`],
    staleTime: 60000, // 1 minute
    refetchInterval: 30000, // Refresh every 30 seconds
    enabled: !!selectedWatchlistId,
  });

  const handleRefresh = () => {
    refetch();
  };

  const columns: ColumnDef<Stock>[] = [
    {
      accessorKey: "symbol",
      header: "Symbol",
      cell: ({ row }) => (
        <div>
          <div className="font-medium">{row.original.symbol}</div>
          <div className="text-xs text-mid-gray">{row.original.companyName}</div>
        </div>
      ),
      meta: {
        className: "p-3 text-left"
      }
    },
    {
      accessorKey: "ltp",
      header: "LTP",
      cell: ({ row }) => (
        <div className="font-medium">{formatCurrency(row.original.ltp)}</div>
      ),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "change",
      header: "Chg.",
      cell: ({ row }) => (
        <div className={getPriceChangeClass(row.original.change)}>
          {row.original.change >= 0 ? "+" : ""}
          {row.original.change.toFixed(2)}
        </div>
      ),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "percentageChange",
      header: "Chg%",
      cell: ({ row }) => (
        <div className={getPriceChangeClass(row.original.percentageChange)}>
          {row.original.percentageChange >= 0 ? "+" : ""}
          {row.original.percentageChange.toFixed(2)}%
        </div>
      ),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "high",
      header: "High",
      cell: ({ row }) => formatCurrency(row.original.high),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "low",
      header: "Low",
      cell: ({ row }) => formatCurrency(row.original.low),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "volume",
      header: "Volume",
      cell: ({ row }) => row.original.volume,
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      id: "actions",
      header: "Action",
      cell: ({ row }) => (
        <div className="flex justify-center space-x-2">
          <Button 
            size="sm" 
            className="py-1 px-3 bg-primary text-white text-xs rounded hover:bg-[#1A4CCA]"
          >
            Trade
          </Button>
          <Button 
            size="sm" 
            variant="outline" 
            className="py-1 px-3 text-xs rounded"
          >
            Chart
          </Button>
        </div>
      ),
      meta: {
        className: "p-3 text-center"
      }
    },
  ];

  return (
    <>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-xl font-bold">Watchlists</h1>
        <div className="flex space-x-2">
          <div className="relative">
            <Input 
              type="text" 
              placeholder="Search stocks..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-white"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-mid-gray" />
          </div>
          <Button 
            onClick={handleRefresh}
            variant="outline" 
            className="bg-white"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <Card className="bg-white shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-light-gray">
          <div className="flex items-center space-x-4">
            <CardTitle className="text-base font-bold">Watchlist</CardTitle>
            <Select 
              value={selectedWatchlistId.toString()} 
              onValueChange={(value) => setSelectedWatchlistId(parseInt(value))}
            >
              <SelectTrigger className="text-sm bg-background border border-light-gray rounded h-8 w-40">
                <SelectValue placeholder="Select Watchlist" />
              </SelectTrigger>
              <SelectContent>
                {isLoadingWatchlists ? (
                  <SelectItem value="1">Loading...</SelectItem>
                ) : (
                  (watchlists || [{ id: 1, name: "My Watchlist" }]).map((watchlist) => (
                    <SelectItem key={watchlist.id} value={watchlist.id.toString()}>
                      {watchlist.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center">
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-primary text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Stock
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Stock to Watchlist</DialogTitle>
                </DialogHeader>
                <div className="mt-4 space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Search Stock</label>
                    <div className="relative">
                      <Input placeholder="e.g. RELIANCE, TCS" />
                      <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-mid-gray" />
                    </div>
                  </div>
                  <Button className="w-full">Add to Watchlist</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto scrollbar-thin">
            <DataTable 
              columns={columns} 
              data={watchlistItems || WATCHLIST_STOCKS}
              isPending={isLoadingItems}
              showPagination={true}
              pageSize={10}
            />
          </div>
        </CardContent>
      </Card>
    </>
  );
};

export default WatchlistPage;
