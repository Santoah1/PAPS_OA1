declare module 'smartapi-javascript' {
  export class SmartAPI {
    constructor(options: { api_key: string });
    
    generateSession(clientId: string, password: string, totp: string): Promise<any>;
    generateAccessTokenFromRefreshToken(clientId: string, refreshToken: string): Promise<any>;
    logout(): Promise<any>;
    getProfile(): Promise<any>;
    searchScrip(query: string): Promise<any>;
    getExpiryDates(symbol: string): Promise<any>;
    getOptionChain(symbol: string, expiryDate: string): Promise<any>;
    placeOrder(orderParams: any): Promise<any>;
    getOrders(): Promise<any>;
    getOrderBook(): Promise<any>;
    getTradeBook(): Promise<any>;
    getRMS(): Promise<any>;
    getHoldings(): Promise<any>;
    getPositions(): Promise<any>;
    getLTP(symbols: any): Promise<any>;
    getOHLC(symbols: any): Promise<any>;
    websocket: any;
  }
}