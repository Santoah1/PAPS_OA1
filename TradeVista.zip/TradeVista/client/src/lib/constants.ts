export const MARKET_INDICES = [
  {
    id: 1,
    name: "NIFTY 50",
    value: 20289.95,
    change: 103.50,
    percentageChange: 0.51
  },
  {
    id: 2,
    name: "SENSEX",
    value: 66729.82,
    change: 385.14,
    percentageChange: 0.58
  },
  {
    id: 3,
    name: "BANK NIFTY",
    value: 44297.80,
    change: -102.45,
    percentageChange: -0.23
  },
  {
    id: 4,
    name: "NIFTY MIDCAP",
    value: 12524.70,
    change: 67.35,
    percentageChange: 0.54
  }
];

export const WATCHLIST_STOCKS = [
  {
    symbol: "NIFTY",
    companyName: "NIFTY 50 Index",
    ltp: 20289.95,
    change: 103.50,
    percentageChange: 0.51,
    high: 20350.75,
    low: 20180.15,
    volume: "N/A"
  },
  {
    symbol: "BANKNIFTY",
    companyName: "BANK NIFTY Index",
    ltp: 44297.80,
    change: -102.45,
    percentageChange: -0.23,
    high: 44450.25,
    low: 44180.75,
    volume: "N/A"
  },
  {
    symbol: "RELIANCE",
    companyName: "Reliance Industries",
    ltp: 2387.80,
    change: 15.25,
    percentageChange: 0.64,
    high: 2405.75,
    low: 2372.15,
    volume: "3.2M"
  },
  {
    symbol: "INFY",
    companyName: "Infosys Limited",
    ltp: 1423.40,
    change: -23.75,
    percentageChange: -1.64,
    high: 1450.30,
    low: 1417.60,
    volume: "2.4M"
  },
  {
    symbol: "HDFCBANK",
    companyName: "HDFC Bank Ltd.",
    ltp: 1556.20,
    change: 7.85,
    percentageChange: 0.51,
    high: 1568.50,
    low: 1545.90,
    volume: "5.7M"
  },
  {
    symbol: "TCS",
    companyName: "Tata Consultancy",
    ltp: 3687.50,
    change: -12.45,
    percentageChange: -0.34,
    high: 3705.75,
    low: 3675.20,
    volume: "1.1M"
  },
  {
    symbol: "TATASTEEL",
    companyName: "Tata Steel Ltd.",
    ltp: 134.55,
    change: 2.35,
    percentageChange: 1.78,
    high: 135.40,
    low: 132.10,
    volume: "8.3M"
  }
];

export const PORTFOLIO_HOLDINGS = [
  {
    symbol: "RELIANCE",
    companyName: "Reliance Industries",
    quantity: 10,
    averagePrice: 2350.30,
    currentPrice: 2387.80,
    currentValue: 23878.00,
    pnl: 820.50,
    pnlPercentage: 3.56
  },
  {
    symbol: "INFY",
    companyName: "Infosys Limited",
    quantity: 15,
    averagePrice: 1430.20,
    currentPrice: 1423.40,
    currentValue: 21351.00,
    pnl: -290.25,
    pnlPercentage: -1.34
  },
  {
    symbol: "HDFCBANK",
    companyName: "HDFC Bank Ltd.",
    quantity: 20,
    averagePrice: 1530.50,
    currentPrice: 1556.20,
    currentValue: 31124.00,
    pnl: 528.40,
    pnlPercentage: 1.73
  }
];

export const RECENT_ORDERS = [
  {
    id: 1,
    symbol: "RELIANCE",
    orderType: "Buy",
    quantity: 10,
    price: 2380.50,
    status: "Executed",
    timestamp: "2023-05-15T10:32:00Z"
  },
  {
    id: 2,
    symbol: "SBIN",
    orderType: "Sell",
    quantity: 25,
    price: 628.75,
    status: "Rejected",
    timestamp: "2023-05-15T09:47:00Z"
  },
  {
    id: 3,
    symbol: "TCS",
    orderType: "Buy",
    quantity: 5,
    price: 3690.00,
    status: "Pending",
    timestamp: "2023-05-15T11:05:00Z"
  }
];

// Chart periods
export const CHART_PERIODS = [
  { label: "1D", value: "1d" },
  { label: "1W", value: "1w" },
  { label: "1M", value: "1m" },
  { label: "1Y", value: "1y" },
  { label: "ALL", value: "all" }
];

// Order types
export const ORDER_TYPES = [
  { label: "Market", value: "market" },
  { label: "Limit", value: "limit" },
  { label: "Stop Loss", value: "stoploss" }
];

// Transaction types
export const TRANSACTION_TYPES = [
  { label: "Buy", value: "buy" },
  { label: "Sell", value: "sell" }
];
