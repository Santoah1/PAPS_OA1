import React from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  BarChart2, 
  ArrowLeftRight, 
  FileText, 
  Folder, 
  Home, 
  LineChart, 
  Settings, 
  User, 
  Wallet,
  TrendingUp 
} from "lucide-react";

interface SidebarLinkProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  isActive: boolean;
}

const SidebarLink = ({ href, icon, children, isActive }: SidebarLinkProps) => {
  // Use direct DOM navigation for more reliable behavior
  const handleClick = () => {
    // Force a hard navigation to the route
    window.location.href = href;
  };

  return (
    <button 
      onClick={handleClick}
      className="w-full text-left"
    >
      <div 
        className={cn(
          "flex items-center px-4 py-3 text-sm hover:bg-background cursor-pointer",
          isActive ? "text-primary font-medium bg-primary bg-opacity-5" : "text-text"
        )}
      >
        {React.cloneElement(icon as React.ReactElement, { 
          className: cn("mr-3", isActive ? "text-primary" : "text-text"),
          size: 18 
        })}
        {children}
      </div>
    </button>
  );
};

const Sidebar: React.FC = () => {
  const [location] = useLocation();

  return (
    <div className="w-64 h-full flex-shrink-0 border-r border-light-gray bg-white hidden md:block">
      <div className="p-4 border-b border-light-gray">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-md bg-primary flex items-center justify-center text-white font-bold">
            MS
          </div>
          <span className="ml-2 font-bold text-lg">Mr_Santosh_Shah</span>
        </div>
      </div>
      
      <ScrollArea className="h-[calc(100%-64px)]">
        <div className="py-2">
          {/* User Account */}
          <div className="p-4 border-b border-light-gray">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                <User className="h-4 w-4 text-mid-gray" />
              </div>
              <div className="ml-2">
                <p className="text-sm font-medium">John Doe</p>
                <p className="text-xs text-mid-gray">ACC123456</p>
              </div>
            </div>
          </div>
          
          {/* Navigation Menu */}
          <div className="py-2">
            <div className="px-4 py-2 text-xs font-semibold text-mid-gray uppercase">Main Menu</div>
            <SidebarLink href="/" icon={<Home />} isActive={location === "/"}>
              Dashboard
            </SidebarLink>
            <SidebarLink href="/orders" icon={<ArrowLeftRight />} isActive={location === "/orders"}>
              Orders
            </SidebarLink>
            <SidebarLink href="/portfolio" icon={<Folder />} isActive={location === "/portfolio"}>
              Portfolio
            </SidebarLink>
            <SidebarLink href="/watchlist" icon={<BarChart2 />} isActive={location === "/watchlist"}>
              Watchlist
            </SidebarLink>
            <SidebarLink href="/market" icon={<LineChart />} isActive={location === "/market"}>
              Market
            </SidebarLink>
            <SidebarLink href="/options" icon={<TrendingUp />} isActive={location === "/options"}>
              Options Chain
            </SidebarLink>
          </div>
          
          <div className="py-2">
            <div className="px-4 py-2 text-xs font-semibold text-mid-gray uppercase">Account</div>
            <SidebarLink href="/funds" icon={<Wallet />} isActive={location === "/funds"}>
              Funds
            </SidebarLink>
            <SidebarLink href="/reports" icon={<FileText />} isActive={location === "/reports"}>
              Reports
            </SidebarLink>
            <SidebarLink href="/settings" icon={<Settings />} isActive={location === "/settings"}>
              Settings
            </SidebarLink>
          </div>
        </div>
      </ScrollArea>
    </div>
  );
};

export default Sidebar;
