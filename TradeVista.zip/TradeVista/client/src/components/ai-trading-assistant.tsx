import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Lightbulb, ArrowUpRight, MessageSquare, Brain } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { formatCurrency, getPriceChangeClass } from "@/lib/utils";

// Type definitions for the component
interface UserSettings {
  id: number;
  userId: number;
  aiEnabled: boolean;
  darkMode: boolean;
  language: string;
  riskTolerance: string;
  aiModel: string;
  lastUpdated: Date;
}

interface TradeSuggestion {
  id: number;
  userId: number;
  symbol: string;
  action: string;
  confidence: number;
  riskLevel: string;
  reason: string;
  targetPrice: number | null;
  stopLoss: number | null;
  expiryDate: Date | null;
  createdAt: Date;
  isRead: boolean;
}

// The AI Trading Assistant component with toggle functionality
export const AITradingAssistant: React.FC = () => {
  const [showChat, setShowChat] = useState(false);
  const queryClient = useQueryClient();

  // Fetch user AI settings
  const { data: userSettings, isLoading: isLoadingSettings } = useQuery<UserSettings>({
    queryKey: ['/api/user/settings'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Fetch AI suggestions
  const { data: suggestions, isLoading: isLoadingSuggestions } = useQuery<TradeSuggestion[]>({
    queryKey: ['/api/ai/suggestions'],
    enabled: userSettings?.aiEnabled === true,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Toggle AI functionality
  const toggleAIMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      return await apiRequest(`/api/user/settings/ai`, {
        method: 'POST',
        body: JSON.stringify({ enabled }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/settings'] });
    },
  });

  // Handle toggle change
  const handleToggleChange = (checked: boolean) => {
    toggleAIMutation.mutate(checked);
  };

  if (isLoadingSettings) {
    return (
      <Card className="border-border/40">
        <CardHeader className="pb-2">
          <Skeleton className="h-6 w-64 mb-2" />
          <Skeleton className="h-4 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-16 w-full" />
        </CardContent>
      </Card>
    );
  }

  // If AI is disabled, show the inactive state
  if (!userSettings?.aiEnabled) {
    return (
      <Card className="border-border/40 bg-card/50">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="text-lg flex items-center">
              <Brain className="mr-2 h-5 w-5 text-primary" />
              AI Trade Guru
            </CardTitle>
            <CardDescription>
              AI-powered trade insights and recommendations
            </CardDescription>
          </div>
          <Switch 
            checked={userSettings?.aiEnabled || false} 
            onCheckedChange={handleToggleChange}
            aria-label="Toggle AI" 
          />
        </CardHeader>
        <CardContent className="text-center py-6">
          <Lightbulb className="h-12 w-12 mx-auto mb-3 text-muted-foreground/50" />
          <p className="text-muted-foreground">
            Enable AI Trade Guru to get personalized trade suggestions and market insights
          </p>
        </CardContent>
        <CardFooter className="pt-0 justify-center">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => handleToggleChange(true)}
          >
            Enable AI Guru
          </Button>
        </CardFooter>
      </Card>
    );
  }

  // Active state with suggestions
  return (
    <Card className="border-primary/20 shadow-sm shadow-primary/10">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle className="text-lg flex items-center">
            <Brain className="mr-2 h-5 w-5 text-primary animate-pulse" />
            AI Trade Guru
          </CardTitle>
          <CardDescription>
            Smart suggestions based on market analysis
          </CardDescription>
        </div>
        <Switch 
          checked={true} 
          onCheckedChange={handleToggleChange}
          aria-label="Toggle AI" 
        />
      </CardHeader>
      <CardContent className="pt-0">
        {isLoadingSuggestions ? (
          <div className="space-y-2">
            <Skeleton className="h-6 w-full" />
            <Skeleton className="h-6 w-full" />
          </div>
        ) : suggestions && suggestions.length > 0 ? (
          <div className="space-y-2">
            {suggestions.slice(0, 2).map((suggestion: TradeSuggestion, i: number) => (
              <div key={i} className="flex items-center justify-between p-2 bg-background rounded-md">
                <div className="flex items-center">
                  <div className={`w-2 h-10 rounded-full mr-3 ${suggestion.riskLevel === 'low' 
                    ? 'bg-green-500' 
                    : suggestion.riskLevel === 'medium' 
                      ? 'bg-yellow-500' 
                      : 'bg-red-500'}`} 
                  />
                  <div>
                    <div className="font-medium">{suggestion.symbol}</div>
                    <div className="text-xs flex items-center">
                      <span className={`${suggestion.action === 'buy' 
                        ? 'text-green-600' 
                        : suggestion.action === 'sell' 
                          ? 'text-red-600' 
                          : 'text-yellow-600'} mr-1 font-medium uppercase`}
                      >
                        {suggestion.action}
                      </span>
                      <span className="text-muted-foreground">
                        • {Math.round(suggestion.confidence * 100)}% confidence
                      </span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-medium">
                    {suggestion.targetPrice && formatCurrency(suggestion.targetPrice)}
                  </div>
                  <div className={`text-xs ${getPriceChangeClass(suggestion.action === 'buy' ? 1 : -1)}`}>
                    {suggestion.action === 'buy' ? '↑ Target' : '↓ Target'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-2">
            <p className="text-muted-foreground">
              No current suggestions available
            </p>
          </div>
        )}
      </CardContent>
      <CardFooter className="gap-2 flex border-t pt-3">
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-xs flex-1"
          onClick={() => setShowChat(!showChat)}
        >
          <MessageSquare className="h-3.5 w-3.5 mr-1.5" />
          {showChat ? "Hide Chat" : "Chat with AI"}
        </Button>
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-xs flex-1"
        >
          <ArrowUpRight className="h-3.5 w-3.5 mr-1.5" />
          See All Suggestions
        </Button>
      </CardFooter>
      
      {showChat && (
        <div className="px-4 pb-4">
          <div className="border rounded-md p-3 text-sm">
            <p className="text-muted-foreground italic">
              AI Chat: This feature is coming soon! You'll be able to ask me about stocks, analyze trends, or get personalized trade advice.
            </p>
          </div>
        </div>
      )}
    </Card>
  );
};

export default AITradingAssistant;