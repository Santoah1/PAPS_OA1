import React, { useState, useEffect } from 'react';
import { useMultiSymbolWebSocket } from '@/hooks/use-websocket';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { TrendingUp, TrendingDown, Search, Plus } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface Stock {
  symbol: string;
  companyName: string;
  lastPrice: number;
  change: number;
  percentageChange: number;
}

interface RealTimeWatchlistProps {
  watchlistId?: number;
  title?: string;
  className?: string;
}

export function RealTimeWatchlist({ 
  watchlistId = 1, 
  title = "My Watchlist", 
  className = "" 
}: RealTimeWatchlistProps) {
  // Fetch watchlist items
  const { data: watchlistItems, isLoading: isLoadingWatchlist } = useQuery({
    queryKey: ['/api/watchlists', watchlistId, 'items'],
    queryFn: async () => {
      const response = await fetch(`/api/watchlists/${watchlistId}/items`);
      if (!response.ok) {
        throw new Error('Failed to fetch watchlist items');
      }
      return response.json() as Promise<Stock[]>;
    }
  });
  
  // Get symbols from watchlist items
  const symbols = watchlistItems?.map(item => item.symbol) || [];
  
  // Subscribe to real-time updates for all symbols
  const { data: realtimeData, isLoading: isLoadingRealtime, error } = useMultiSymbolWebSocket(symbols);
  
  // For search/add stock functionality
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  
  // Search for stocks
  const { data: searchResults, isLoading: isSearching } = useQuery({
    queryKey: ['/api/market/search', searchQuery],
    queryFn: async () => {
      if (!searchQuery || searchQuery.length < 2) return [];
      
      const response = await fetch(`/api/market/search?query=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) {
        throw new Error('Failed to search stocks');
      }
      return response.json() as Promise<Stock[]>;
    },
    enabled: searchQuery.length >= 2
  });
  
  // Handle adding a stock to watchlist
  const addToWatchlist = async (symbol: string, companyName: string) => {
    try {
      const response = await fetch(`/api/watchlists/${watchlistId}/items`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          symbol,
          companyName
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to add to watchlist');
      }
      
      // Close dialog and reset search
      setIsAddDialogOpen(false);
      setSearchQuery('');
      
      // Invalidate watchlist query to refresh
      // We would use queryClient.invalidateQueries(['watchlist', watchlistId]) here
      // but for simplicity we'll just reload the page
      window.location.reload();
      
    } catch (error) {
      console.error('Error adding to watchlist:', error);
    }
  };
  
  // Combined loading state
  const isLoading = isLoadingWatchlist || (symbols.length > 0 && isLoadingRealtime);
  
  if (error) {
    return (
      <Card className={className}>
        <CardHeader>
          <CardTitle className="flex justify-between">
            <span>{title}</span>
            <Button size="sm" onClick={() => window.location.reload()}>Retry</Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 text-red-500 text-center">
            {error}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex justify-between items-center">
          <span>{title}</span>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1">
                <Plus className="h-4 w-4" /> Add Stock
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Add to Watchlist</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-2">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search for stocks..."
                    className="pl-8"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                
                <div className="min-h-[200px] max-h-[300px] overflow-y-auto">
                  {isSearching ? (
                    <div className="flex flex-col gap-2">
                      <Skeleton className="h-10 w-full" />
                      <Skeleton className="h-10 w-full" />
                      <Skeleton className="h-10 w-full" />
                    </div>
                  ) : searchResults && searchResults.length > 0 ? (
                    <Table>
                      <TableBody>
                        {searchResults.map((stock) => (
                          <TableRow key={stock.symbol}>
                            <TableCell>
                              <div className="font-medium">{stock.symbol}</div>
                              <div className="text-xs text-muted-foreground">{stock.companyName}</div>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button 
                                size="sm" 
                                onClick={() => addToWatchlist(stock.symbol, stock.companyName)}
                              >
                                Add
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  ) : searchQuery.length >= 2 ? (
                    <div className="text-center p-4 text-muted-foreground">
                      No stocks found matching "{searchQuery}"
                    </div>
                  ) : (
                    <div className="text-center p-4 text-muted-foreground">
                      Type at least 2 characters to search
                    </div>
                  )}
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : watchlistItems && watchlistItems.length > 0 ? (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Symbol</TableHead>
                <TableHead>Company</TableHead>
                <TableHead className="text-right">Price</TableHead>
                <TableHead className="text-right">Change</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {watchlistItems.map((item) => {
                // Use real-time data if available, otherwise use data from API
                const realtimeStock = realtimeData[item.symbol];
                const price = realtimeStock?.ltp || item.lastPrice;
                const change = realtimeStock?.change || item.change;
                const percentChange = realtimeStock?.changePercent || item.percentageChange;
                const isPositive = change >= 0;
                
                return (
                  <TableRow key={item.symbol}>
                    <TableCell className="font-medium">{item.symbol}</TableCell>
                    <TableCell className="text-sm text-muted-foreground truncate max-w-[150px]">
                      {item.companyName}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      ₹{(price !== undefined && price !== null) ? price.toFixed(2) : "0.00"}
                    </TableCell>
                    <TableCell className="text-right">
                      <Badge variant={isPositive ? 'success' : 'destructive'} className="flex items-center gap-1 ml-auto w-fit">
                        {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                        {isPositive ? '+' : ''}{(change !== undefined && change !== null) ? change.toFixed(2) : "0.00"} ({(percentChange !== undefined && percentChange !== null) ? percentChange.toFixed(2) : "0.00"}%)
                      </Badge>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        ) : (
          <div className="text-center p-6 text-muted-foreground">
            <p>No stocks in your watchlist yet.</p>
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-2"
              onClick={() => setIsAddDialogOpen(true)}
            >
              <Plus className="h-4 w-4 mr-1" /> Add your first stock
            </Button>
          </div>
        )}
        
        {realtimeData && Object.keys(realtimeData).length > 0 && (
          <div className="text-xs text-right text-muted-foreground mt-2">
            Real-time data enabled · Last updated: {new Date().toLocaleTimeString()}
          </div>
        )}
      </CardContent>
    </Card>
  );
}