import React, { useState, useEffect } from 'react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Loader2, RefreshCw } from "lucide-react";
import { useQuery } from '@tanstack/react-query';
import { getOptionExpiryDates, getOptionChain } from '@/lib/api';
import { getPriceChangeClass, formatCurrency } from '@/lib/utils';

interface OptionChainProps {
  symbol: string;
  refreshInterval?: number; // In milliseconds
}

export default function OptionChainComponent({ symbol, refreshInterval = 10000 }: OptionChainProps) {
  const [selectedExpiry, setSelectedExpiry] = useState<string | null>(null);
  
  // Fetch available expiry dates
  const {
    data: expiryDates,
    isLoading: isLoadingDates,
    isError: isErrorDates,
  } = useQuery({
    queryKey: ['/api/options/expiry-dates', symbol],
    queryFn: () => getOptionExpiryDates(symbol),
    refetchInterval: refreshInterval,
  });
  
  // Set default expiry date once loaded
  useEffect(() => {
    if (expiryDates && expiryDates.length > 0 && !selectedExpiry) {
      setSelectedExpiry(expiryDates[0]);
    }
  }, [expiryDates, selectedExpiry]);
  
  // Fetch option chain based on selected expiry date
  const {
    data: optionChain,
    isLoading: isLoadingChain,
    isError: isErrorChain,
    refetch: refetchChain,
  } = useQuery({
    queryKey: ['/api/options/chain', symbol, selectedExpiry],
    queryFn: () => selectedExpiry ? getOptionChain(symbol, selectedExpiry) : Promise.reject("No expiry date selected"),
    enabled: !!selectedExpiry,
    refetchInterval: refreshInterval,
  });
  
  // Handle refresh button click
  const handleRefresh = () => {
    refetchChain();
  };
  
  // Combined loading and error states
  const isLoading = isLoadingDates || isLoadingChain;
  const isError = isErrorDates || isErrorChain;
  
  if (isLoadingDates) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
        <span className="ml-2">Loading expiry dates...</span>
      </div>
    );
  }
  
  if (isErrorDates) {
    return (
      <div className="p-4 text-center text-red-500">
        Failed to load expiry dates. Please try again.
      </div>
    );
  }
  
  return (
    <div className="bg-card rounded-lg shadow-sm">
      <div className="p-4 border-b flex justify-between items-center">
        <div className="flex items-center gap-2">
          <h3 className="text-lg font-semibold">Option Chain</h3>
          <Badge variant="outline" className="text-xs font-normal">
            {symbol}
          </Badge>
          {optionChain && (
            <div className="text-sm text-muted-foreground ml-2">
              Spot Price: {formatCurrency(optionChain.spotPrice)}
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex items-center">
            <span className="text-sm mr-2">Expiry:</span>
            <Select
              value={selectedExpiry || ''}
              onValueChange={(value) => setSelectedExpiry(value)}
            >
              <SelectTrigger className="w-[180px] h-8">
                <SelectValue placeholder="Select expiry date" />
              </SelectTrigger>
              <SelectContent>
                {expiryDates?.map((date) => (
                  <SelectItem key={date} value={date}>
                    {date}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <button 
            onClick={handleRefresh}
            className="h-8 w-8 rounded-full flex items-center justify-center hover:bg-accent"
            title="Refresh data"
          >
            <RefreshCw className="h-4 w-4" />
          </button>
        </div>
      </div>
      
      <div className="overflow-auto">
        {isLoadingChain ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="ml-2">Loading option chain...</span>
          </div>
        ) : isErrorChain ? (
          <div className="p-4 text-center text-red-500">
            Failed to load option chain. Please try again.
          </div>
        ) : optionChain ? (
          <div>
            <div className="text-xs text-right text-muted-foreground px-4 pt-2">
              Last updated: {new Date(optionChain.lastUpdated).toLocaleTimeString()}
            </div>
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="text-center font-semibold w-1/5" colSpan={3}>CALLS</TableHead>
                  <TableHead className="text-center font-semibold w-1/5">STRIKE PRICE</TableHead>
                  <TableHead className="text-center font-semibold w-1/5" colSpan={3}>PUTS</TableHead>
                </TableRow>
                <TableRow className="bg-muted/50 text-xs">
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead className="text-right">Chg%</TableHead>
                  <TableHead className="text-right">OI</TableHead>
                  <TableHead className="text-center font-medium">Strike</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead className="text-right">Chg%</TableHead>
                  <TableHead className="text-right">OI</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {optionChain.options.map((option) => (
                  <TableRow key={option.strikePrice} className="text-xs hover:bg-muted/30">
                    <TableCell className={`text-right font-medium ${getPriceChangeClass(option.callChange)}`}>
                      {formatCurrency(option.callPrice)}
                    </TableCell>
                    <TableCell className={`text-right ${getPriceChangeClass(option.callChangePercent)}`}>
                      {option.callChangePercent > 0 ? '+' : ''}{option.callChangePercent.toFixed(2)}%
                    </TableCell>
                    <TableCell className="text-right">{option.oi?.toLocaleString()}</TableCell>
                    <TableCell className={`text-center font-semibold ${
                      optionChain.spotPrice > option.strikePrice ? 'text-green-600' : 
                      optionChain.spotPrice < option.strikePrice ? 'text-red-600' : ''
                    }`}>
                      {formatCurrency(option.strikePrice)}
                    </TableCell>
                    <TableCell className={`text-right font-medium ${getPriceChangeClass(option.putChange)}`}>
                      {formatCurrency(option.putPrice)}
                    </TableCell>
                    <TableCell className={`text-right ${getPriceChangeClass(option.putChangePercent)}`}>
                      {option.putChangePercent > 0 ? '+' : ''}{option.putChangePercent.toFixed(2)}%
                    </TableCell>
                    <TableCell className="text-right">{option.oi?.toLocaleString()}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="p-4 text-center text-muted-foreground">
            Select an expiry date to view option chain
          </div>
        )}
      </div>
    </div>
  );
}