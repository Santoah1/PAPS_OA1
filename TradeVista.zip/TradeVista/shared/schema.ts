import { pgTable, text, serial, integer, boolean, timestamp, real, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const watchlists = pgTable("watchlists", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
});

export const insertWatchlistSchema = createInsertSchema(watchlists).pick({
  userId: true,
  name: true,
});

export type InsertWatchlist = z.infer<typeof insertWatchlistSchema>;
export type Watchlist = typeof watchlists.$inferSelect;

export const watchlistItems = pgTable("watchlist_items", {
  id: serial("id").primaryKey(),
  watchlistId: integer("watchlist_id").notNull().references(() => watchlists.id),
  symbol: text("symbol").notNull(),
  companyName: text("company_name").notNull(),
});

export const insertWatchlistItemSchema = createInsertSchema(watchlistItems).pick({
  watchlistId: true,
  symbol: true,
  companyName: true,
});

export type InsertWatchlistItem = z.infer<typeof insertWatchlistItemSchema>;
export type WatchlistItem = typeof watchlistItems.$inferSelect;

export const holdings = pgTable("holdings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  symbol: text("symbol").notNull(),
  companyName: text("company_name").notNull(),
  quantity: integer("quantity").notNull(),
  averagePrice: real("average_price").notNull(),
  investmentValue: real("investment_value").notNull(),
});

export const insertHoldingSchema = createInsertSchema(holdings).pick({
  userId: true,
  symbol: true,
  companyName: true,
  quantity: true,
  averagePrice: true,
  investmentValue: true,
});

export type InsertHolding = z.infer<typeof insertHoldingSchema>;
export type Holding = typeof holdings.$inferSelect & {
  // Runtime properties (not stored in DB)
  currentPrice?: number;
  currentValue?: number;
  pnl?: number;
  pnlPercentage?: number;
};

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  symbol: text("symbol").notNull(),
  orderType: text("order_type").notNull(),
  transactionType: text("transaction_type").notNull(),
  quantity: integer("quantity").notNull(),
  price: real("price").notNull(),
  status: text("status").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  userId: true,
  symbol: true,
  orderType: true,
  transactionType: true,
  quantity: true,
  price: true,
  status: true,
});

export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type Order = typeof orders.$inferSelect;

export const marketIndices = pgTable("market_indices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  value: real("value").notNull(),
  change: real("change").notNull(),
  percentageChange: real("percentage_change").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertMarketIndexSchema = createInsertSchema(marketIndices).pick({
  name: true,
  value: true,
  change: true,
  percentageChange: true,
});

export type InsertMarketIndex = z.infer<typeof insertMarketIndexSchema>;
export type MarketIndex = typeof marketIndices.$inferSelect;

// Stock representation for price data
export const stockSchema = z.object({
  symbol: z.string(),
  companyName: z.string(),
  ltp: z.number(),
  change: z.number(),
  percentageChange: z.number(),
  high: z.number(),
  low: z.number(),
  volume: z.string(),
  data: z.array(z.object({
    time: z.string(),
    price: z.number()
  })).optional()
});

export type Stock = z.infer<typeof stockSchema>;

// Chart data point
export const chartDataSchema = z.object({
  time: z.string(),
  price: z.number()
});

export type ChartData = z.infer<typeof chartDataSchema>;

// Option chain data for derivatives
export const optionChainSchema = z.object({
  strikePrice: z.number(),
  callPrice: z.number(),
  callChange: z.number(),
  callChangePercent: z.number(),
  putPrice: z.number(),
  putChange: z.number(), 
  putChangePercent: z.number(),
  oi: z.number().optional(),
  volume: z.number().optional(),
  iv: z.number().optional(),
});

export type OptionChain = z.infer<typeof optionChainSchema>;

// Option chain for a specific index or stock
export const optionChainListSchema = z.object({
  symbol: z.string(),
  expiryDate: z.string(),
  spotPrice: z.number(),
  lastUpdated: z.string(),
  options: z.array(optionChainSchema)
});

export type OptionChainList = z.infer<typeof optionChainListSchema>;

// User AI preferences
export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id).unique(),
  aiEnabled: boolean("ai_enabled").notNull().default(false),
  darkMode: boolean("dark_mode").notNull().default(false),
  language: text("language").notNull().default("hinglish"),
  riskTolerance: text("risk_tolerance").notNull().default("medium"),
  aiModel: text("ai_model").notNull().default("gpt-4o"),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).pick({
  userId: true,
  aiEnabled: true,
  darkMode: true,
  language: true,
  riskTolerance: true,
  aiModel: true,
});

export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type UserSettings = typeof userSettings.$inferSelect;

// AI trade suggestions
export const tradeSuggestions = pgTable("trade_suggestions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  symbol: text("symbol").notNull(),
  action: text("action").notNull(), // buy, sell, hold
  confidence: real("confidence").notNull(), // 0.0 to 1.0
  riskLevel: text("risk_level").notNull(), // low, medium, high
  reason: text("reason").notNull(),
  targetPrice: real("target_price"),
  stopLoss: real("stop_loss"),
  expiryDate: timestamp("expiry_date"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  isRead: boolean("is_read").notNull().default(false),
});

export const insertTradeSuggestionSchema = createInsertSchema(tradeSuggestions);

export type InsertTradeSuggestion = z.infer<typeof insertTradeSuggestionSchema>;
export type TradeSuggestion = typeof tradeSuggestions.$inferSelect;
