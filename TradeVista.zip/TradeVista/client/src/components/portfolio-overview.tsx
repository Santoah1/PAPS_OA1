import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { getHoldings, getPortfolioSummary } from "@/lib/api";
import { formatCurrency, getPriceChangeClass } from "@/lib/utils";
import { PORTFOLIO_HOLDINGS } from "@/lib/constants";
import { Link } from "wouter";

const PortfolioOverview: React.FC = () => {
  const { data: holdings, isLoading: isLoadingHoldings } = useQuery({
    queryKey: ['/api/portfolio/holdings'],
    staleTime: 60000, // 1 minute
    refetchInterval: 60000, // Refresh every minute
  });

  const { data: summary, isLoading: isLoadingSummary } = useQuery({
    queryKey: ['/api/portfolio/summary'],
    staleTime: 60000, // 1 minute
    refetchInterval: 60000, // Refresh every minute
  });

  const defaultSummary = {
    currentValue: 487235.75,
    investedValue: 474777.45,
    totalPnl: 12458.30,
    totalPnlPercentage: 2.6,
    availableMargin: 125000.00
  };

  return (
    <Card className="bg-white rounded-lg shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-light-gray">
        <CardTitle className="font-bold">Portfolio Overview</CardTitle>
        <Link href="/portfolio">
          <Button variant="link" className="text-primary text-sm p-0 h-auto">
            View All
          </Button>
        </Link>
      </CardHeader>
      
      <CardContent className="p-4">
        {isLoadingSummary ? (
          <div className="flex justify-between items-center mb-4">
            <div>
              <Skeleton className="h-4 w-24 mb-2" />
              <Skeleton className="h-8 w-32" />
            </div>
            <div className="text-right">
              <Skeleton className="h-4 w-20 mb-2" />
              <Skeleton className="h-6 w-28" />
            </div>
          </div>
        ) : (
          <div className="flex justify-between items-center mb-4">
            <div>
              <p className="text-sm text-mid-gray">Current Value</p>
              <p className="text-xl font-bold">
                {formatCurrency((summary?.currentValue || defaultSummary.currentValue))}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-mid-gray">Total P&L</p>
              <p className={`text-lg font-bold ${
                getPriceChangeClass((summary?.totalPnl || defaultSummary.totalPnl))
              }`}>
                {(summary?.totalPnl !== undefined ? summary.totalPnl : defaultSummary.totalPnl) >= 0 ? "+" : ""}
                {formatCurrency((summary?.totalPnl !== undefined ? summary.totalPnl : defaultSummary.totalPnl))} 
                ({(summary?.totalPnlPercentage !== undefined ? summary.totalPnlPercentage : defaultSummary.totalPnlPercentage) >= 0 ? "+" : ""}
                {(summary?.totalPnlPercentage !== undefined ? summary.totalPnlPercentage : defaultSummary.totalPnlPercentage).toFixed(2)}%)
              </p>
            </div>
          </div>
        )}
        
        {isLoadingSummary ? (
          <div className="mb-4 pb-4 border-b border-light-gray">
            <div className="flex justify-between text-sm mb-2">
              <Skeleton className="h-4 w-16" />
              <Skeleton className="h-4 w-24" />
            </div>
            <div className="flex justify-between text-sm">
              <Skeleton className="h-4 w-28" />
              <Skeleton className="h-4 w-24" />
            </div>
          </div>
        ) : (
          <div className="mb-4 pb-4 border-b border-light-gray">
            <div className="flex justify-between text-sm mb-1">
              <span className="text-mid-gray">Invested</span>
              <span>{formatCurrency((summary?.investedValue || defaultSummary.investedValue))}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-mid-gray">Available Margin</span>
              <span>{formatCurrency((summary?.availableMargin || defaultSummary.availableMargin))}</span>
            </div>
          </div>
        )}
        
        <h3 className="font-medium mb-3">Top Holdings</h3>
        
        {isLoadingHoldings ? (
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="flex justify-between items-center mb-3 p-2 rounded">
              <div>
                <Skeleton className="h-5 w-20 mb-1" />
                <Skeleton className="h-3 w-16" />
              </div>
              <div className="text-right">
                <Skeleton className="h-5 w-20 mb-1" />
                <Skeleton className="h-3 w-24" />
              </div>
            </div>
          ))
        ) : (
          (holdings || PORTFOLIO_HOLDINGS).slice(0, 3).map((holding) => (
            <div key={holding.symbol} className="flex justify-between items-center mb-3 p-2 hover:bg-background rounded">
              <div>
                <p className="font-medium">{holding.symbol}</p>
                <p className="text-xs text-mid-gray">{holding.quantity} shares</p>
              </div>
              <div className="text-right">
                <p className="font-medium">{formatCurrency(holding.currentValue)}</p>
                <p className={`text-xs ${getPriceChangeClass(holding.pnl || 0)}`}>
                  {(holding.pnl || 0) >= 0 ? "+" : ""}
                  {formatCurrency(holding.pnl || 0)} ({(holding.pnlPercentage || 0) >= 0 ? "+" : ""}
                  {(holding.pnlPercentage || 0).toFixed(2)}%)
                </p>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
};

export default PortfolioOverview;
