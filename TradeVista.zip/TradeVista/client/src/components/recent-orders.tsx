import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { getRecentOrders } from "@/lib/api";
import { getOrderStatusClass, formatCurrency, formatTime } from "@/lib/utils";
import { RECENT_ORDERS } from "@/lib/constants";
import { Link } from "wouter";

const RecentOrders: React.FC = () => {
  const { data: orders, isLoading } = useQuery({
    queryKey: ['/api/orders/recent'],
    staleTime: 60000, // 1 minute
  });

  return (
    <Card className="bg-white rounded-lg shadow-sm">
      <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-light-gray">
        <CardTitle className="font-bold">Recent Orders</CardTitle>
        <Link href="/orders">
          <Button variant="link" className="text-primary text-sm p-0 h-auto">
            View All
          </Button>
        </Link>
      </CardHeader>
      
      <CardContent className="p-3">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <div key={i} className="border-b border-light-gray py-3 last:border-b-0">
              <div className="flex justify-between">
                <Skeleton className="h-5 w-20" />
                <Skeleton className="h-5 w-16" />
              </div>
              <div className="flex justify-between mt-1 text-sm">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-16" />
              </div>
            </div>
          ))
        ) : (
          (orders || RECENT_ORDERS).map((order) => (
            <div key={order.id} className="border-b border-light-gray py-3 last:border-b-0">
              <div className="flex justify-between">
                <span className="font-medium">{order.symbol}</span>
                <Badge className={`text-xs px-2 py-0.5 rounded-full ${getOrderStatusClass(order.status)}`}>
                  {order.status}
                </Badge>
              </div>
              <div className="flex justify-between mt-1 text-sm">
                <span className="text-mid-gray">
                  {order.orderType} {order.quantity} @ {formatCurrency(order.price)}
                </span>
                <span className="text-mid-gray">
                  {formatTime(new Date(order.timestamp))}
                </span>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
};

export default RecentOrders;
