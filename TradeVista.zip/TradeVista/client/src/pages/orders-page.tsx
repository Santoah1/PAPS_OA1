import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { DataTable } from "@/components/ui/data-table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { getOrders } from "@/lib/api";
import { getOrderStatusClass, formatCurrency, formatTime } from "@/lib/utils";
import { ColumnDef } from "@tanstack/react-table";
import { Order } from "@shared/schema";
import { RECENT_ORDERS } from "@/lib/constants";
import { Search } from "lucide-react";

const OrdersPage: React.FC = () => {
  const [orderStatus, setOrderStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const { data: orders, isLoading } = useQuery({
    queryKey: ['/api/orders'],
    staleTime: 60000, // 1 minute
  });

  const filteredOrders = React.useMemo(() => {
    const data = orders || RECENT_ORDERS.concat(RECENT_ORDERS).concat(RECENT_ORDERS);
    
    return data.filter(order => {
      // Filter by status
      if (orderStatus !== "all" && order.status.toLowerCase() !== orderStatus) {
        return false;
      }
      
      // Filter by search query
      if (searchQuery && !order.symbol.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      
      return true;
    });
  }, [orders, orderStatus, searchQuery]);

  const columns: ColumnDef<Order>[] = [
    {
      accessorKey: "symbol",
      header: "Symbol",
      cell: ({ row }) => (
        <div className="font-medium">{row.original.symbol}</div>
      ),
      meta: {
        className: "p-3 text-left"
      }
    },
    {
      accessorKey: "orderType",
      header: "Type",
      cell: ({ row }) => (
        <div className={row.original.orderType === "Buy" ? "text-primary" : "text-secondary"}>
          {row.original.orderType}
        </div>
      ),
      meta: {
        className: "p-3 text-left"
      }
    },
    {
      accessorKey: "quantity",
      header: "Quantity",
      cell: ({ row }) => row.original.quantity,
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "price",
      header: "Price",
      cell: ({ row }) => formatCurrency(row.original.price),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }) => (
        <Badge className={`text-xs px-2 py-0.5 rounded-full ${getOrderStatusClass(row.original.status)}`}>
          {row.original.status}
        </Badge>
      ),
      meta: {
        className: "p-3 text-center"
      }
    },
    {
      accessorKey: "timestamp",
      header: "Time",
      cell: ({ row }) => formatTime(new Date(row.original.timestamp)),
      meta: {
        className: "p-3 text-right"
      }
    },
    {
      id: "actions",
      header: "Action",
      cell: ({ row }) => (
        <Button 
          size="sm" 
          variant="outline"
          disabled={row.original.status !== "Pending"}
          className="py-1 px-3 text-xs rounded"
        >
          Cancel
        </Button>
      ),
      meta: {
        className: "p-3 text-center"
      }
    },
  ];

  return (
    <>
      <div className="mb-6">
        <h1 className="text-xl font-bold mb-4">Orders</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-white shadow-sm">
            <CardContent className="p-4">
              <div className="text-sm text-mid-gray mb-1">Total Orders</div>
              <div className="text-2xl font-bold">
                {filteredOrders.length}
              </div>
              <div className="text-sm mt-1 text-mid-gray">
                Last 30 days
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white shadow-sm">
            <CardContent className="p-4">
              <div className="text-sm text-mid-gray mb-1">Executed Orders</div>
              <div className="text-2xl font-bold">
                {filteredOrders.filter(order => order.status === "Executed").length}
              </div>
              <div className="text-sm mt-1 text-success">
                Success Rate: {Math.round((filteredOrders.filter(order => order.status === "Executed").length / filteredOrders.length) * 100)}%
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-white shadow-sm">
            <CardContent className="p-4">
              <div className="text-sm text-mid-gray mb-1">Pending Orders</div>
              <div className="text-2xl font-bold">
                {filteredOrders.filter(order => order.status === "Pending").length}
              </div>
              <div className="text-sm mt-1 text-primary">
                Awaiting execution
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Card className="bg-white shadow-sm">
        <CardHeader className="flex flex-row items-center justify-between p-4 border-b border-light-gray">
          <CardTitle className="font-bold">Order History</CardTitle>
          <div className="flex items-center space-x-2">
            <div className="relative">
              <Input 
                type="text" 
                placeholder="Search by symbol..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-60"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-mid-gray" />
            </div>
            <Tabs value={orderStatus} onValueChange={setOrderStatus} className="w-auto">
              <TabsList>
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="executed">Executed</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="rejected">Rejected</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <DataTable
            columns={columns}
            data={filteredOrders}
            isPending={isLoading}
            showPagination={true}
            pageSize={10}
          />
        </CardContent>
      </Card>
    </>
  );
};

export default OrdersPage;
