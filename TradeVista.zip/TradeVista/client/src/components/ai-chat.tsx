import React, { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Message {
  text: string;
  isUser: boolean;
  timestamp: Date;
}

export const AIChat: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    { 
      text: "नमस्ते! मैं आपका AI ट्रेडिंग सहायक हूँ। मैं आपको स्टॉक्स, मार्केट ट्रेंड्स, और ट्रेडिंग स्ट्रैटेजी के बारे में मदद कर सकता हूँ। कृपया बताएं, मैं आपकी क्या सहायता कर सकता हूँ?", 
      isUser: false, 
      timestamp: new Date() 
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const toggleChat = () => {
    setIsOpen(!isOpen);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && input.trim()) {
      handleSendMessage();
    }
  };

  const getAIResponse = (userMessage: string): string => {
    // Simple responses based on keywords
    const lowerMsg = userMessage.toLowerCase();
    
    if (lowerMsg.includes('hello') || lowerMsg.includes('hi') || lowerMsg.includes('namaste') || lowerMsg.includes('नमस्ते')) {
      return "नमस्ते! कैसे मदद कर सकता हूँ आज?";
    }
    else if (lowerMsg.includes('stock') || lowerMsg.includes('share') || lowerMsg.includes('शेयर')) {
      return "आज बाजार में कई अच्छे अवसर हैं। किसी विशेष शेयर के बारे में जानना चाहते हैं?";
    }
    else if (lowerMsg.includes('reliance') || lowerMsg.includes('ril')) {
      return "रिलायंस के शेयर की वर्तमान कीमत ₹2,832.25 है। पिछले एक महीने में इसमें 3.2% की वृद्धि हुई है।";
    }
    else if (lowerMsg.includes('nifty') || lowerMsg.includes('sensex') || lowerMsg.includes('market')) {
      return "वर्तमान में NIFTY 50 का मूल्य 20,289.75 है। आज इसमें +14.80 (0.07%) की वृद्धि देखी गई है।";
    }
    else if (lowerMsg.includes('buy') || lowerMsg.includes('sell') || lowerMsg.includes('खरीद') || lowerMsg.includes('बेच')) {
      return "किसी भी ट्रेडिंग निर्णय से पहले अपना विश्लेषण करें। क्या आप किसी विशेष स्टॉक के बारे में सलाह चाहते हैं?";
    }
    else if (lowerMsg.includes('thanks') || lowerMsg.includes('thank you') || lowerMsg.includes('धन्यवाद') || lowerMsg.includes('शुक्रिया')) {
      return "आपका स्वागत है! और कुछ पूछना चाहते हैं?";
    }
    else {
      return "मुझे क्षमा करें, मैं आपका प्रश्न समझ नहीं पाया। क्या आप स्टॉक मार्केट, ट्रेडिंग स्ट्रैटेजी, या किसी विशेष शेयर के बारे में पूछना चाहते हैं?";
    }
  };

  const handleSendMessage = () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      text: input,
      isUser: true,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput("");
    setIsTyping(true);
    
    // Simulate AI thinking and responding
    setTimeout(() => {
      const aiResponse: Message = {
        text: getAIResponse(input),
        isUser: false,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1000);
  };

  return (
    <>
      {/* Floating button */}
      <Button
        onClick={toggleChat}
        className="fixed bottom-6 right-6 shadow-lg rounded-full h-14 w-14 p-0 bg-primary hover:bg-primary/90 flex items-center justify-center z-50"
      >
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </Button>

      {/* Chat overlay */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 sm:right-10 w-[90%] sm:w-96 shadow-xl rounded-md bg-white border border-gray-200 overflow-hidden z-50 flex flex-col max-h-[500px]">
          <div className="p-3 bg-primary text-white flex justify-between items-center">
            <h3 className="font-medium">AI Trade Assistant</h3>
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleChat}
              className="h-6 w-6 p-0 text-white hover:bg-primary/90 hover:text-white"
            >
              <X size={16} />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto p-3 bg-gray-50 h-[400px]">
            <div className="space-y-4">
              {messages.map((msg, index) => (
                <div key={index} className={`flex ${msg.isUser ? 'justify-end' : 'justify-start'}`}>
                  <div 
                    className={`max-w-[85%] rounded-lg p-3 ${
                      msg.isUser 
                        ? 'bg-primary text-white rounded-br-none' 
                        : 'bg-white shadow-sm border border-gray-200 rounded-bl-none'
                    }`}
                  >
                    <p className="text-sm">{msg.text}</p>
                    <p className="text-xs mt-1 opacity-70">
                      {msg.timestamp.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </p>
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white shadow-sm border border-gray-200 rounded-lg rounded-bl-none p-3 max-w-[85%]">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{animationDelay: '0s'}}></div>
                      <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{animationDelay: '0.2s'}}></div>
                      <div className="w-2 h-2 rounded-full bg-gray-300 animate-bounce" style={{animationDelay: '0.4s'}}></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </div>

          <div className="p-3 border-t border-gray-200 flex items-center">
            <Input
              value={input}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              placeholder="पूछें... (Hinglish में प्रश्न पूछें)"
              className="text-sm"
            />
            <Button
              size="icon"
              onClick={handleSendMessage}
              className={`ml-2 ${input.trim() ? 'bg-primary hover:bg-primary/90' : 'bg-gray-300'}`}
              disabled={!input.trim()}
            >
              <Send size={16} />
            </Button>
          </div>
        </div>
      )}
    </>
  );
};

export default AIChat;