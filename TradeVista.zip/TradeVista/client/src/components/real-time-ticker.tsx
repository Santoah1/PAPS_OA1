import React from 'react';
import { useSymbolWebSocket } from '@/hooks/use-websocket';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface RealTimeTickerProps {
  symbol: string;
  showDetails?: boolean;
}

export function RealTimeTicker({ symbol, showDetails = false }: RealTimeTickerProps) {
  const { data, isLoading, error } = useSymbolWebSocket(symbol);
  
  if (error) {
    return (
      <Card className="w-full">
        <CardContent className="py-3">
          <div className="text-red-500 text-sm">{error}</div>
        </CardContent>
      </Card>
    );
  }
  
  if (isLoading || !data) {
    return (
      <Card className="w-full">
        <CardContent className="py-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-semibold">{symbol}</p>
              <Skeleton className="h-4 w-20 mt-1" />
            </div>
            <Skeleton className="h-6 w-24" />
          </div>
          {showDetails && (
            <div className="grid grid-cols-4 gap-2 mt-3">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
            </div>
          )}
        </CardContent>
      </Card>
    );
  }
  
  const isPositive = data.change >= 0;
  const changePercent = data.changePercent ? data.changePercent.toFixed(2) : '0.00';
  
  return (
    <Card className="w-full transition-shadow duration-300 hover:shadow-md">
      <CardContent className="py-3">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-semibold">{data.symbol}</p>
            <p className="text-sm text-muted-foreground">{data.exchange}</p>
          </div>
          <div className="flex flex-col items-end">
            <p className="font-bold">₹{data.ltp?.toFixed(2) || '0.00'}</p>
            <Badge variant={isPositive ? 'success' : 'destructive'} className="flex items-center gap-1">
              {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              {isPositive ? '+' : ''}{data.change?.toFixed(2) || '0.00'} ({changePercent}%)
            </Badge>
          </div>
        </div>
        
        {showDetails && (
          <div className="grid grid-cols-4 gap-4 mt-4 text-sm">
            <div>
              <p className="text-muted-foreground">Open</p>
              <p className="font-medium">₹{data.open?.toFixed(2) || 'N/A'}</p>
            </div>
            <div>
              <p className="text-muted-foreground">High</p>
              <p className="font-medium">₹{data.high?.toFixed(2) || 'N/A'}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Low</p>
              <p className="font-medium">₹{data.low?.toFixed(2) || 'N/A'}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Volume</p>
              <p className="font-medium">{data.volume?.toLocaleString() || 'N/A'}</p>
            </div>
          </div>
        )}
        
        <div className="mt-1 text-xs text-right text-muted-foreground">
          Last updated: {new Date(data.timestamp).toLocaleTimeString()}
        </div>
      </CardContent>
    </Card>
  );
}

interface MultiTickerProps {
  symbols: string[];
  className?: string;
}

export function MultiTicker({ symbols, className = '' }: MultiTickerProps) {
  return (
    <div className={`grid gap-2 ${className}`}>
      {symbols.map(symbol => (
        <RealTimeTicker key={symbol} symbol={symbol} />
      ))}
    </div>
  );
}