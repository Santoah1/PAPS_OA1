# Deployment Instructions for PAPS_OA1

## GitHub Pages Deployment Steps

### Step 1: Clone the Repository
```bash
git clone https://github.com/Santoah1/PAPS_OA1.git
cd PAPS_OA1
```

### Step 2: Update Vite Configuration
After cloning, update `vite.config.ts` to add the base path for GitHub Pages:

Add this line in the `defineConfig` function:
```javascript
base: '/PAPS_OA1/',
```

So the beginning of your config should look like:
```javascript
export default defineConfig({
  base: '/PAPS_OA1/', // Base path for GitHub Pages
  plugins: [
    // ...
  ],
  // ...
});
```

### Step 3: Install Dependencies
```bash
npm install
```

### Step 4: Build the Project
```bash
npm run build
```

### Step 5: Deploy to GitHub Pages
The GitHub Actions workflow will automatically deploy the project to GitHub Pages whenever you push to the main branch.

### Step 6: Access Your Deployed Application
Once deployed, your application will be available at:
```
https://Santoah1.github.io/PAPS_OA1/
```

## Important Notes:
1. The GitHub Pages deployment only hosts the frontend part of the application.
2. For the backend to work, you'll need to deploy it separately on a server that supports Node.js.
3. Update environment variables in GitHub repository secrets for secure storage.