import React from "react";
import MarketOverview from "@/components/market-overview";
import StockChart from "@/components/stock-chart";
import { RealTimeTicker } from "@/components/real-time-ticker";
import { RealTimeWatchlist } from "@/components/real-time-watchlist";
import TradingPanel from "@/components/trading-panel";
import PortfolioOverview from "@/components/portfolio-overview";
import RecentOrders from "@/components/recent-orders";
import AITradingAssistant from "@/components/ai-trading-assistant";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Info } from 'lucide-react';

const Dashboard: React.FC = () => {
  return (
    <>
      <Alert className="mb-4">
        <Info className="h-4 w-4" />
        <AlertTitle>Real-time updates enabled</AlertTitle>
        <AlertDescription>
          This dashboard now supports real-time market data via WebSockets. Stock prices and watchlist items will update automatically.
        </AlertDescription>
      </Alert>
      
      <MarketOverview />
      
      <div className="grid grid-cols-12 gap-4 mt-4">
        <div className="col-span-12 lg:col-span-8">
          <StockChart symbol="RELIANCE" name="Reliance Industries" />
          
          <div className="mb-4 mt-4">
            <RealTimeTicker symbol="RELIANCE" showDetails={true} />
          </div>
          
          <RealTimeWatchlist title="My Watchlist" className="mt-4" />
        </div>

        <div className="col-span-12 lg:col-span-4 space-y-4">
          <TradingPanel defaultSymbol="RELIANCE" />
          <AITradingAssistant />
          <PortfolioOverview />
          <RecentOrders />
        </div>
      </div>
    </>
  );
};

export default Dashboard;
