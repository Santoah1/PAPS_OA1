import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { webSocketService } from "./services/webSocketService";
import { 
  stockSchema, 
  insertWatchlistSchema, 
  insertWatchlistItemSchema,
  insertOrderSchema,
  insertMarketIndexSchema,
  optionChainListSchema,
  insertUserSettingsSchema,
  insertTradeSuggestionSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Market data endpoints
  app.get("/api/market/indices", async (req, res) => {
    try {
      const indices = await storage.getMarketIndices();
      res.json(indices);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch market indices" });
    }
  });

  app.get("/api/market/stock/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const stock = await storage.getStockPrice(symbol);
      
      if (!stock) {
        return res.status(404).json({ message: "Stock not found" });
      }
      
      res.json(stock);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stock price" });
    }
  });

  app.get("/api/market/chart/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const { period = "1d" } = req.query;
      
      const stock = await storage.getStockChart(symbol, period as string);
      
      if (!stock) {
        return res.status(404).json({ message: "Chart data not found" });
      }
      
      res.json(stock);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chart data" });
    }
  });

  app.get("/api/market/search", async (req, res) => {
    try {
      const { query } = req.query;
      
      if (!query || typeof query !== "string") {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const stocks = await storage.searchStocks(query);
      res.json(stocks);
    } catch (error) {
      res.status(500).json({ message: "Failed to search stocks" });
    }
  });
  
  // Option chain endpoints
  app.get("/api/options/:symbol/expiry-dates", async (req, res) => {
    try {
      const { symbol } = req.params;
      const expiryDates = await storage.getExpiryDates(symbol);
      res.json(expiryDates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch expiry dates" });
    }
  });
  
  app.get("/api/options/:symbol/chain", async (req, res) => {
    try {
      const { symbol } = req.params;
      const { expiryDate } = req.query;
      
      if (!expiryDate || typeof expiryDate !== "string") {
        return res.status(400).json({ message: "Expiry date is required" });
      }
      
      const optionChain = await storage.getOptionChain(symbol, expiryDate);
      
      if (!optionChain) {
        return res.status(404).json({ message: "Option chain not found" });
      }
      
      res.json(optionChain);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch option chain" });
    }
  });

  // Watchlist endpoints
  app.get("/api/watchlists", async (req, res) => {
    try {
      const watchlists = await storage.getWatchlists(1); // Hardcoded user ID for now
      res.json(watchlists);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch watchlists" });
    }
  });

  app.post("/api/watchlists", async (req, res) => {
    try {
      const data = insertWatchlistSchema.parse({
        ...req.body,
        userId: 1 // Hardcoded user ID for now
      });
      
      const watchlist = await storage.createWatchlist(data);
      res.status(201).json(watchlist);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid watchlist data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create watchlist" });
    }
  });

  app.get("/api/watchlists/:id/items", async (req, res) => {
    try {
      const { id } = req.params;
      const items = await storage.getWatchlistItems(parseInt(id));
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch watchlist items" });
    }
  });

  app.post("/api/watchlists/:id/items", async (req, res) => {
    try {
      const { id } = req.params;
      const data = insertWatchlistItemSchema.parse({
        ...req.body,
        watchlistId: parseInt(id)
      });
      
      const item = await storage.addToWatchlist(data);
      res.status(201).json(item);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid watchlist item data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add item to watchlist" });
    }
  });

  app.delete("/api/watchlists/:watchlistId/items/:itemId", async (req, res) => {
    try {
      const { watchlistId, itemId } = req.params;
      await storage.removeFromWatchlist(parseInt(watchlistId), parseInt(itemId));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to remove item from watchlist" });
    }
  });

  // Portfolio endpoints
  app.get("/api/portfolio/holdings", async (req, res) => {
    try {
      const holdings = await storage.getHoldings(1); // Hardcoded user ID for now
      res.json(holdings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch holdings" });
    }
  });

  app.get("/api/portfolio/summary", async (req, res) => {
    try {
      const summary = await storage.getPortfolioSummary(1); // Hardcoded user ID for now
      res.json(summary);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch portfolio summary" });
    }
  });

  // Order endpoints
  app.get("/api/orders", async (req, res) => {
    try {
      const orders = await storage.getOrders(1); // Hardcoded user ID for now
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/recent", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const orders = await storage.getRecentOrders(1, limit); // Hardcoded user ID for now
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent orders" });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const data = insertOrderSchema.parse({
        ...req.body,
        userId: 1, // Hardcoded user ID for now
        status: "Pending" // Default status
      });
      
      const order = await storage.placeOrder(data);
      res.status(201).json(order);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid order data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to place order" });
    }
  });

  // User endpoints
  app.get("/api/user/margin", async (req, res) => {
    try {
      const margin = await storage.getAvailableMargin(1); // Hardcoded user ID for now
      res.json({ margin });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch available margin" });
    }
  });
  
  // User settings endpoints
  app.get("/api/user/settings", async (req, res) => {
    try {
      const userId = 1; // Hardcoded user ID for now
      let settings = await storage.getUserSettings(userId);
      
      // If settings don't exist yet, create default settings
      if (!settings) {
        const defaultSettings = {
          userId,
          aiEnabled: true,
          darkMode: false,
          language: "hinglish",
          riskTolerance: "medium",
          aiModel: "gpt-4o"
        };
        
        settings = await storage.createUserSettings(defaultSettings);
      }
      
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user settings" });
    }
  });
  
  app.post("/api/user/settings", async (req, res) => {
    try {
      const userId = 1; // Hardcoded user ID for now
      const data = insertUserSettingsSchema.parse({
        ...req.body,
        userId,
        aiEnabled: req.body.aiEnabled ?? false,
        darkMode: req.body.darkMode ?? false,
        language: req.body.language ?? "hinglish",
        riskTolerance: req.body.riskTolerance ?? "medium",
        aiModel: req.body.aiModel ?? "gpt-4o"
      });
      
      // Check if settings exist
      let settings = await storage.getUserSettings(userId);
      
      if (settings) {
        settings = await storage.updateUserSettings(userId, data);
      } else {
        settings = await storage.createUserSettings(data);
      }
      
      res.json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid settings data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update user settings" });
    }
  });
  
  app.post("/api/user/settings/ai", async (req, res) => {
    try {
      const userId = 1; // Hardcoded user ID for now
      const { enabled } = req.body;
      
      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ message: "Invalid parameter: enabled must be a boolean" });
      }
      
      const settings = await storage.toggleAI(userId, enabled);
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to toggle AI settings" });
    }
  });
  
  app.post("/api/user/settings/darkmode", async (req, res) => {
    try {
      const userId = 1; // Hardcoded user ID for now
      const { enabled } = req.body;
      
      if (typeof enabled !== 'boolean') {
        return res.status(400).json({ message: "Invalid parameter: enabled must be a boolean" });
      }
      
      const settings = await storage.toggleDarkMode(userId, enabled);
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to toggle dark mode settings" });
    }
  });
  
  // AI Trade suggestion endpoints
  app.get("/api/ai/suggestions", async (req, res) => {
    try {
      const userId = 1; // Hardcoded user ID for now
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      
      const suggestions = await storage.getTradeSuggestions(userId, limit);
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch AI trade suggestions" });
    }
  });
  
  app.post("/api/ai/suggestions", async (req, res) => {
    try {
      const data = insertTradeSuggestionSchema.parse({
        ...req.body,
        userId: 1, // Hardcoded user ID for now
        isRead: false // Default value
      });
      
      const suggestion = await storage.createTradeSuggestion(data);
      res.status(201).json(suggestion);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid suggestion data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create AI trade suggestion" });
    }
  });
  
  app.post("/api/ai/suggestions/:id/read", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.markTradeSuggestionAsRead(parseInt(id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to mark suggestion as read" });
    }
  });

  const httpServer = createServer(app);
  
  // Initialize WebSocket server with a specific path to avoid conflicts with Vite HMR
  webSocketService.initialize(httpServer, '/api/ws');
  
  return httpServer;
}
