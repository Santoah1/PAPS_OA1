import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Define interfaces separately to fix LSP errors
interface TelegramWebApp {
  [key: string]: any;
}

interface TelegramInterface {
  WebApp?: TelegramWebApp;
  [key: string]: any;
}

interface TelegramGameProxyInterface {
  [key: string]: any;
}

// Extend the Window interface properly
declare global {
  interface Window {
    Telegram?: TelegramInterface;
    TelegramGameProxy?: TelegramGameProxyInterface;
  }
}

// Safety check for Telegram object to prevent errors
if (typeof window !== 'undefined') {
  // Initialize objects if they don't exist
  window.Telegram = window.Telegram || {};
  window.Telegram.WebApp = window.Telegram.WebApp || {};
  window.TelegramGameProxy = window.TelegramGameProxy || {};
}

createRoot(document.getElementById("root")!).render(<App />);
